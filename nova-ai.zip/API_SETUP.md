# API Setup Guide

NOVA AI stores all provider API keys exclusively in server-side environment variables. Only models belonging to configured providers are exposed in the model selector.

## Required

- `GEMINI_API_KEY`: Enables Google Gemini models (`gemini-4-hydrogen`, `gemini-3.1-flash-lite`, `gemini-3.8-flash-lite-tts`, `gemini-3.5-transcribe`, `gemini-embedding-2`), live Google Search grounding, multimodal vision, and Vector Studio.

## Optional Multi-Provider Keys

- `OPENAI_API_KEY`: Enables `gpt-4o`, `gpt-4o-mini`, and DALL-E 3 raster generation in `/image-studio`.
- `ANTHROPIC_API_KEY`: Enables `claude-3-5-sonnet-latest` and `claude-3-5-haiku-latest`.
- `OPENROUTER_API_KEY`: Enables `meta-llama/llama-3.3-70b-instruct`.
- `ENABLE_PAID_GEMINI_IMAGE`: Set `"true"` only if `GEMINI_API_KEY` is attached to a billing-enabled Google Cloud project.

## Optional Payment Gateways

- `RAZORPAY_KEY_ID` & `RAZORPAY_KEY_SECRET`: For INR subscription verification.
- `STRIPE_SECRET_KEY`: For global card checkout verification.
