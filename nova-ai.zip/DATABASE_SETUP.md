# Database Setup Guide

## Default Local Relational Persistence (Zero Setup)

NOVA AI ships with an embedded relational SQLite database powered by Node.js 22's built-in `node:sqlite` (`server/db/index.ts`), stored at `./data/nova.db` (configurable via `NOVA_DB_PATH`).

Tables initialized automatically:
- `users`, `user_preferences`, `password_resets`
- `conversations`, `messages`, `user_feedback`
- `uploaded_files`, `document_chunks`
- `generated_images`, `user_memories`, `coding_projects`
- `ai_usage`, `system_settings`, `error_logs`, `admin_audit_logs`

## Production Supabase / PostgreSQL + pgvector Migration

To migrate to managed PostgreSQL with `pgvector` and Row Level Security:

1. Create a Supabase project and open the SQL Editor.
2. Execute `supabase/migrations/001_initial_schema.sql`.
3. Verify `vector` extension and RLS policies are active on all user-owned tables.
4. Keep `SUPABASE_SERVICE_ROLE_KEY` exclusively on server routes.
