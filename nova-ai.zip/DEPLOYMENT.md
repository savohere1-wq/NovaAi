# Production Deployment Guide

## 1. Build & Verify

```bash
npm run lint
npm run build
```

Start the production Express server (serves compiled `dist/` assets + `/api/*` endpoints on port `3000`):

```bash
npm start
```

## 2. Environment Variables

Set these securely in your hosting provider (Cloud Run, Railway, Fly.io, Render, or Vercel + Node backend):
- `NODE_ENV=production`
- `PORT=3000`
- `GEMINI_API_KEY`
- `JWT_SECRET` (minimum 32 random bytes)
- `ADMIN_EMAIL` (account email granted admin role on registration)
- Optional: `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `OPENROUTER_API_KEY`, `NOVA_DB_PATH`

## 3. Security & Monitoring Checklist

- Serve behind HTTPS so `Secure` HTTP-only cookies and Web Audio / `getUserMedia` microphone APIs work across browsers.
- Monitor `/api/health` for uptime checks.
- Inspect `/admin` for real-time API usage totals, error logs, and administrative audit trails.
- Back up `./data/nova.db` (or enable automated point-in-time recovery on PostgreSQL).
