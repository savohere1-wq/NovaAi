# NOVA AI

NOVA AI is a full-stack, multi-model AI intelligence platform combining real-time streaming chat, Google Search-grounded web research, document RAG, private long-term memory, voice AI, an image/vector studio, 15 specialized AI tools, and a sandboxed coding workspace.

## Core Architecture

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Motion, Lucide Icons, React Markdown, KaTeX, Highlight.js.
- **Backend**: Node.js 22 + Express (`server.ts`) with Server-Sent Events (SSE) streaming, Helmet security headers, rate limiting, Multer file ingestion, and server-side AI adapters.
- **Persistence**: Built-in relational SQLite (`node:sqlite` in `./data/nova.db`) with foreign keys and indexes, plus a full PostgreSQL + `pgvector` + Row Level Security migration at `supabase/migrations/001_initial_schema.sql`.
- **Authentication & RBAC**: Email registration/login, bcrypt password hashing, JWT HTTP-only cookies + Bearer token headers, password recovery tokens, and server-verified `admin` role enforcement.

## Quick Start

1. Install dependencies:
   ```bash
   npm install
   ```
2. Configure environment variables (copy `.env.example` to `.env` and set `GEMINI_API_KEY` and `JWT_SECRET`).
3. Start development server on port `3000`:
   ```bash
   npm run dev
   ```
4. Type-check and build for production:
   ```bash
   npm run lint
   npm run build
   npm start
   ```

## Documentation

- [API_SETUP.md](./API_SETUP.md) — Multi-provider AI, search, and payment credentials.
- [DATABASE_SETUP.md](./DATABASE_SETUP.md) — Local SQLite persistence and Supabase PostgreSQL + `pgvector` migration guide.
- [DEPLOYMENT.md](./DEPLOYMENT.md) — Production build, HTTPS, monitoring, and deployment steps.
