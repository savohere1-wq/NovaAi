import type { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { db } from '../db/index.ts';
import type { PlanTier, UserProfile, UserRole } from '../../src/types/nova.ts';

// Ephemeral fallback secret for local dev when JWT_SECRET is not set
const FALLBACK_DEV_SECRET = crypto.randomBytes(32).toString('hex');

function getJwtSecret(): string {
  return process.env.JWT_SECRET || FALLBACK_DEV_SECRET;
}

export interface AuthenticatedRequest extends Request {
  user?: UserProfile;
}

interface JwtPayload {
  sub: string;
  email: string;
  role: UserRole;
}

export function signAuthToken(user: { id: string; email: string; role: UserRole }): string {
  return jwt.sign(
    { sub: user.id, email: user.email, role: user.role },
    getJwtSecret(),
    { expiresIn: '7d' }
  );
}

export function verifyAuthToken(token: string): JwtPayload | null {
  try {
    return jwt.verify(token, getJwtSecret()) as JwtPayload;
  } catch {
    return null;
  }
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export async function comparePassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function getUserById(id: string): UserProfile | null {
  const row = db
    .prepare('SELECT id, email, name, role, plan, avatar_url, created_at FROM users WHERE id = ?')
    .get(id) as
    | {
        id: string;
        email: string;
        name: string;
        role: UserRole;
        plan: PlanTier;
        avatar_url: string | null;
        created_at: string;
      }
    | undefined;
  if (!row) return null;
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    role: row.role,
    plan: row.plan,
    avatarUrl: row.avatar_url,
    createdAt: row.created_at,
  };
}

function extractToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }
  const cookieToken = (req as Request & { cookies?: Record<string, string> }).cookies?.nova_session;
  if (cookieToken) {
    return cookieToken;
  }
  return null;
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const token = extractToken(req);
  if (!token) {
    return res.status(401).json({ error: 'Authentication required. Please sign in.' });
  }
  const decoded = verifyAuthToken(token);
  if (!decoded) {
    return res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
  }
  const user = getUserById(decoded.sub);
  if (!user) {
    return res.status(401).json({ error: 'Account not found.' });
  }
  req.user = user;
  next();
}

export function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  requireAuth(req, res, () => {
    if (!req.user || req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Administrator privileges required.' });
    }
    next();
  });
}

export function setAuthCookie(res: Response, token: string) {
  res.cookie('nova_session', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: '/',
  });
}

export function clearAuthCookie(res: Response) {
  res.clearCookie('nova_session', { path: '/' });
}

