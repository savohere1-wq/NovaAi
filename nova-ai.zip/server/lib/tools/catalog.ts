export interface AIToolDefinition {
  id: string;
  name: string;
  category: 'Writing' | 'Engineering' | 'Research & Study' | 'Business & Creative';
  description: string;
  fields: Array<{
    key: string;
    label: string;
    type: 'text' | 'textarea' | 'select';
    placeholder?: string;
    options?: string[];
    required?: boolean;
  }>;
  useSearch?: boolean;
  thinkingMode?: 'low' | 'medium' | 'high';
  buildPrompt: (input: Record<string, string>) => { system: string; prompt: string };
}

export const AI_TOOLS_CATALOG: AIToolDefinition[] = [
  {
    id: 'writer',
    name: 'AI Writing Assistant',
    category: 'Writing',
    description: 'Draft articles, essays, technical blogs, or polished prose with tone and audience calibration.',
    fields: [
      { key: 'topic', label: 'Topic or Draft', type: 'textarea', placeholder: 'Describe what you want to write or paste a draft to refine...', required: true },
      { key: 'tone', label: 'Tone', type: 'select', options: ['Executive & Clear', 'Technical & Precise', 'Editorial Storytelling', 'Conversational', 'Academic'] },
      { key: 'length', label: 'Length', type: 'select', options: ['Concise (~300 words)', 'Standard (~650 words)', 'In-Depth (~1200 words)'] },
    ],
    buildPrompt: (i) => ({
      system: 'You are an expert senior editor and writer. Produce crisp, original, well-structured prose without fluff.',
      prompt: `Write a piece with tone "${i.tone || 'Executive & Clear'}" and target length "${i.length || 'Standard'}".\n\nTopic/Draft:\n${i.topic}`,
    }),
  },
  {
    id: 'coding',
    name: 'AI Coding Assistant',
    category: 'Engineering',
    description: 'Generate production code, debug root causes, or refactor modules with clean architecture.',
    thinkingMode: 'high',
    fields: [
      { key: 'language', label: 'Language / Stack', type: 'select', options: ['TypeScript / React', 'Python', 'Node.js / Express', 'SQL / PostgreSQL', 'Go', 'Rust'] },
      { key: 'task', label: 'Task Type', type: 'select', options: ['Generate Implementation', 'Debug & Fix', 'Refactor & Optimize', 'Write Unit Tests'] },
      { key: 'code', label: 'Requirements or Source Code', type: 'textarea', placeholder: 'Describe the feature or paste code to debug/refactor...', required: true },
    ],
    buildPrompt: (i) => ({
      system: 'You are a principal software engineer. Provide clean, type-safe, edge-case-hardened code with concise architectural notes.',
      prompt: `Language: ${i.language || 'TypeScript'}\nTask: ${i.task || 'Generate Implementation'}\n\nDetails:\n${i.code}`,
    }),
  },
  {
    id: 'math',
    name: 'AI Math Solver',
    category: 'Research & Study',
    description: 'Solve calculus, linear algebra, probability, and competition math step by step with LaTeX notation.',
    thinkingMode: 'high',
    fields: [
      { key: 'problem', label: 'Math Problem', type: 'textarea', placeholder: 'Enter an equation, proof, integral, or word problem...', required: true },
      { key: 'level', label: 'Explanation Level', type: 'select', options: ['Step-by-Step Detailed', 'Final Proof & Verification', 'Intuitive Conceptual'] },
    ],
    buildPrompt: (i) => ({
      system: 'You are a rigorous mathematics professor. Show step-by-step derivations using LaTeX ($...$ and $$...$$) and verify the final answer.',
      prompt: `Explanation style: ${i.level || 'Step-by-Step Detailed'}\n\nProblem:\n${i.problem}`,
    }),
  },
  {
    id: 'researcher',
    name: 'AI Research Assistant',
    category: 'Research & Study',
    description: 'Live Google Search-grounded synthesis with verified clickable citations and key takeaways.',
    useSearch: true,
    fields: [
      { key: 'query', label: 'Research Question', type: 'textarea', placeholder: 'What topic, recent event, or technical standard do you want researched?', required: true },
      { key: 'depth', label: 'Report Format', type: 'select', options: ['Executive Brief + Citations', 'Comparative Analysis', 'Technical Literature Review'] },
    ],
    buildPrompt: (i) => ({
      system: 'You are a factual research analyst. Ground every recent claim in search results, distinguish sourced facts from interpretation, and never invent citations.',
      prompt: `Format: ${i.depth || 'Executive Brief + Citations'}\n\nResearch Question:\n${i.query}`,
    }),
  },
  {
    id: 'translator',
    name: 'AI Translator',
    category: 'Writing',
    description: 'High-accuracy translation across English, Hindi, Hinglish, Spanish, French, Japanese, and more.',
    fields: [
      { key: 'sourceText', label: 'Source Text', type: 'textarea', placeholder: 'Paste text to translate...', required: true },
      { key: 'targetLang', label: 'Target Language', type: 'select', options: ['Hindi (Devanagari)', 'Hinglish (Roman Hindi)', 'English', 'Spanish', 'French', 'German', 'Japanese'] },
      { key: 'register', label: 'Register', type: 'select', options: ['Natural / Idiomatic', 'Formal / Business', 'Literal / Technical'] },
    ],
    buildPrompt: (i) => ({
      system: 'You are a native-level literary and technical translator. Preserve meaning, nuance, and formatting.',
      prompt: `Translate the following text into ${i.targetLang || 'Hindi (Devanagari)'} using a ${i.register || 'Natural / Idiomatic'} register. Also list key cultural or terminology notes if helpful.\n\nText:\n${i.sourceText}`,
    }),
  },
  {
    id: 'resume',
    name: 'AI Resume Builder',
    category: 'Business & Creative',
    description: 'Transform experience notes into ATS-ready, impact-quantified resume bullets and summaries.',
    fields: [
      { key: 'role', label: 'Target Job Title', type: 'text', placeholder: 'e.g., Senior Full-Stack Engineer', required: true },
      { key: 'background', label: 'Experience, Skills & Achievements', type: 'textarea', placeholder: 'Paste your current resume or raw career notes...', required: true },
      { key: 'jobDesc', label: 'Target Job Description (Optional)', type: 'textarea', placeholder: 'Paste JD keywords to tailor against...' },
    ],
    buildPrompt: (i) => ({
      system: 'You are an executive technical recruiter and resume strategist. Craft crisp, ATS-compatible Markdown resumes using action verbs and measurable metrics without fabricating experience.',
      prompt: `Target Role: ${i.role}\n\nCandidate Background:\n${i.background}\n\nTarget Job Description:\n${i.jobDesc || 'None provided'}`,
    }),
  },
  {
    id: 'email',
    name: 'AI Email Writer',
    category: 'Writing',
    description: 'Compose crisp client outreach, executive updates, follow-ups, and difficult replies.',
    fields: [
      { key: 'goal', label: 'Email Objective & Context', type: 'textarea', placeholder: 'Who are you writing to and what outcome do you need?', required: true },
      { key: 'tone', label: 'Tone', type: 'select', options: ['Professional & Warm', 'Direct & Executive', 'Persuasive Outreach', 'Diplomatic'] },
    ],
    buildPrompt: (i) => ({
      system: 'You are an executive communications advisor. Provide Subject line options and a concise, high-clarity email body.',
      prompt: `Tone: ${i.tone || 'Professional & Warm'}\n\nContext:\n${i.goal}`,
    }),
  },
  {
    id: 'content',
    name: 'AI Content Generator',
    category: 'Business & Creative',
    description: 'Create multi-platform launch posts, video scripts, newsletters, and product copy.',
    fields: [
      { key: 'format', label: 'Content Format', type: 'select', options: ['LinkedIn Thought Leadership', 'YouTube / Video Script', 'Product Launch Announcement', 'Newsletter Issue', 'Twitter/X Thread'] },
      { key: 'brief', label: 'Product / Topic Brief', type: 'textarea', placeholder: 'Describe your product, audience, and key message...', required: true },
    ],
    buildPrompt: (i) => ({
      system: 'You are a senior content strategist. Produce engaging, concrete, zero-cliché content tailored to the platform.',
      prompt: `Format: ${i.format || 'LinkedIn Thought Leadership'}\n\nBrief:\n${i.brief}`,
    }),
  },
  {
    id: 'data-analyst',
    name: 'AI Data Analyst',
    category: 'Engineering',
    description: 'Analyze CSV/JSON metrics, detect anomalies, write SQL/Python queries, and summarize KPIs.',
    thinkingMode: 'high',
    fields: [
      { key: 'data', label: 'Dataset Sample or Metrics', type: 'textarea', placeholder: 'Paste CSV rows, JSON, or tabular metrics...', required: true },
      { key: 'question', label: 'Analysis Goal', type: 'text', placeholder: 'e.g., Identify churn drivers and suggest SQL queries', required: true },
    ],
    buildPrompt: (i) => ({
      system: 'You are a staff data analyst. Compute exact figures from the provided data, highlight anomalies, and provide reproducible SQL or Python analysis snippets.',
      prompt: `Goal: ${i.question}\n\nData:\n${i.data}`,
    }),
  },
  {
    id: 'study',
    name: 'AI Study Assistant',
    category: 'Research & Study',
    description: 'Generate active-recall flashcards, concept breakdowns, and practice quizzes.',
    fields: [
      { key: 'subject', label: 'Subject / Notes', type: 'textarea', placeholder: 'Enter a concept or paste lecture notes...', required: true },
      { key: 'mode', label: 'Study Mode', type: 'select', options: ['Feynman Concept Breakdown', '10 Practice Quiz Questions + Answers', 'Active Recall Flashcards', 'Exam Revision Cheat Sheet'] },
    ],
    buildPrompt: (i) => ({
      system: 'You are a master tutor. Teach clearly using concrete analogies, structured summaries, and active recall checks.',
      prompt: `Study Mode: ${i.mode || 'Feynman Concept Breakdown'}\n\nMaterial:\n${i.subject}`,
    }),
  },
  {
    id: 'presentation',
    name: 'AI Presentation Creator',
    category: 'Business & Creative',
    description: 'Architect slide-by-slide pitch decks with speaker notes, visual cues, and key metrics.',
    fields: [
      { key: 'topic', label: 'Presentation Topic & Audience', type: 'textarea', placeholder: 'e.g., Series A investor deck for an AI logistics startup...', required: true },
      { key: 'slides', label: 'Slide Count', type: 'select', options: ['6 Slides (Quick Pitch)', '10 Slides (Standard Deck)', '14 Slides (Board Review)'] },
    ],
    buildPrompt: (i) => ({
      system: 'You are a management consultant and deck architect. Output each slide with Headline, 3 concise bullet points, Visual Layout Recommendation, and Speaker Notes.',
      prompt: `Target slides: ${i.slides || '10 Slides'}\n\nBrief:\n${i.topic}`,
    }),
  },
  {
    id: 'website-builder',
    name: 'AI Website Builder',
    category: 'Engineering',
    description: 'Generate clean, responsive HTML + Tailwind CSS landing pages ready to preview in Coding Workspace.',
    fields: [
      { key: 'brand', label: 'Site Purpose & Brand', type: 'textarea', placeholder: 'Describe the business, sections needed, and visual aesthetic...', required: true },
      { key: 'palette', label: 'Visual Style', type: 'select', options: ['Dark Obsidian & Violet', 'Minimalist Light Editorial', 'Enterprise Slate & Blue'] },
    ],
    buildPrompt: (i) => ({
      system: 'You are a senior frontend engineer. Output a complete single-file HTML document using Tailwind CDN (<script src="https://cdn.tailwindcss.com"></script>) inside a ```html fenced code block with semantic markup and responsive layout.',
      prompt: `Visual Style: ${i.palette || 'Dark Obsidian & Violet'}\n\nWebsite Specification:\n${i.brand}`,
    }),
  },
  {
    id: 'image-prompt',
    name: 'AI Image Prompt Architect',
    category: 'Business & Creative',
    description: 'Craft studio-grade visual prompts with lighting, camera, and composition specs for Image Studio.',
    fields: [
      { key: 'concept', label: 'Visual Idea', type: 'textarea', placeholder: 'Describe the scene, subject, or product you want to generate...', required: true },
      { key: 'medium', label: 'Medium', type: 'select', options: ['Photorealistic Editorial', 'Architectural 3D Render', 'Technical Isometric Diagram', 'Minimalist Vector Illustration'] },
    ],
    buildPrompt: (i) => ({
      system: 'You are a creative director. Produce 3 distinct, highly detailed image generation prompts with lighting, lens/medium, palette, and framing parameters.',
      prompt: `Medium: ${i.medium || 'Photorealistic Editorial'}\n\nConcept:\n${i.concept}`,
    }),
  },
  {
    id: 'pdf-summarizer',
    name: 'AI Text & Document Summarizer',
    category: 'Research & Study',
    description: 'Distill long reports, transcripts, or pasted document excerpts into executive summaries and action items.',
    fields: [
      { key: 'text', label: 'Document Content', type: 'textarea', placeholder: 'Paste document text here (or use /documents for PDF/DOCX/XLSX file uploads)...', required: true },
      { key: 'outputType', label: 'Output Format', type: 'select', options: ['Executive Summary + Key Takeaways', 'Action Items & Risks', 'Structured Technical Brief'] },
    ],
    buildPrompt: (i) => ({
      system: 'You are an executive analyst. Summarize strictly from the provided text without adding external assumptions.',
      prompt: `Format: ${i.outputType || 'Executive Summary + Key Takeaways'}\n\nContent:\n${i.text}`,
    }),
  },
  {
    id: 'business',
    name: 'AI Business Assistant',
    category: 'Business & Creative',
    description: 'Build go-to-market strategies, SWOT analyses, unit economics models, and SOPs.',
    thinkingMode: 'high',
    fields: [
      { key: 'challenge', label: 'Business Challenge or Plan', type: 'textarea', placeholder: 'Describe your product, market, pricing, or operational question...', required: true },
      { key: 'framework', label: 'Framework', type: 'select', options: ['Go-To-Market & Pricing Strategy', 'SWOT & Competitive Moat', 'Unit Economics & Risk Matrix', 'Standard Operating Procedure (SOP)'] },
    ],
    buildPrompt: (i) => ({
      system: 'You are a pragmatic startup COO and strategy advisor. Deliver actionable frameworks, concrete KPIs, and clear trade-offs.',
      prompt: `Framework: ${i.framework || 'Go-To-Market & Pricing Strategy'}\n\nContext:\n${i.challenge}`,
    }),
  },
];
