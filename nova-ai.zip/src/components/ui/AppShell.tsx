import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  BarChart3,
  Brain,
  ChevronDown,
  Code2,
  CreditCard,
  FileText,
  History,
  Image as ImageIcon,
  Layers,
  LogIn,
  LogOut,
  Menu,
  MessageSquare,
  Moon,
  PanelLeftClose,
  PanelLeftOpen,
  Phone,
  Plus,
  Search,
  Settings,
  Shield,
  Sun,
  Trash2,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { apiFetch } from '../../lib/api';
import type { Conversation } from '../../types/nova';

interface AppShellProps {
  currentPath: string;
  navigate: (path: string) => void;
  activeConversationId?: string | null;
  onSelectConversation?: (id: string) => void;
  onNewChat?: () => void;
  refreshTrigger?: number;
  children: React.ReactNode;
}

export function AppShell({
  currentPath,
  navigate,
  activeConversationId,
  onSelectConversation,
  onNewChat,
  refreshTrigger,
  children,
}: AppShellProps) {
  const { user, theme, setTheme, logout, notify } = useAuth();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [conversations, setConversations] = useState<Conversation[]>([]);

  const loadConversations = async (q = '') => {
    if (!user) return;
    try {
      const url = q ? `/api/conversations?q=${encodeURIComponent(q)}` : '/api/conversations';
      const data = await apiFetch<{ conversations: Conversation[] }>(url);
      setConversations(data.conversations || []);
    } catch {
      // ignore initial load failures
    }
  };

  useEffect(() => {
    void loadConversations(searchQuery);
  }, [user, refreshTrigger, searchQuery]);

  const handleDeleteConversation = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    try {
      await apiFetch(`/api/conversations/${id}`, { method: 'DELETE' });
      setConversations((prev) => prev.filter((c) => c.id !== id));
      if (activeConversationId === id && onNewChat) {
        onNewChat();
      }
      notify('Conversation deleted', 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to delete conversation', 'error');
    }
  };

  const primaryNav = [
    { path: '/', label: 'Chat', icon: MessageSquare, matchPaths: ['/', '/chat'] },
    { path: '/voice', label: 'Voice Call', icon: Phone, matchPaths: ['/voice'] },
    { path: '/image-studio', label: 'Image Studio', icon: ImageIcon, matchPaths: ['/image-studio'] },
    { path: '/documents', label: 'Documents', icon: FileText, matchPaths: ['/documents'] },
    { path: '/tools', label: 'AI Tools', icon: Layers, matchPaths: ['/tools'] },
  ];

  const secondaryNav = [
    { path: '/workspace', label: 'Coding Studio', icon: Code2 },
    { path: '/memory', label: 'Memory', icon: Brain },
    { path: '/history', label: 'History', icon: History },
    { path: '/dashboard', label: 'Usage', icon: BarChart3 },
    { path: '/subscription', label: 'Plans', icon: CreditCard },
    { path: '/settings', label: 'Settings', icon: Settings },
  ];

  if (user?.role === 'admin') {
    secondaryNav.push({ path: '/admin', label: 'Admin', icon: Shield });
  }

  const isSecondaryActive = secondaryNav.some((item) => item.path === currentPath);
  const showMore = moreOpen || isSecondaryActive;

  const sidebarContent = (isMobile: boolean) => (
    <div className="flex flex-col h-full bg-white dark:bg-[#0E0E11] border-r border-zinc-200 dark:border-zinc-800/80 select-none">
      {/* Brand + Collapse */}
      <div className="flex items-center justify-between px-4 h-14 border-b border-zinc-200 dark:border-zinc-800/80 shrink-0">
        {(!collapsed || isMobile) && (
          <button
            type="button"
            onClick={() => {
              if (onNewChat) onNewChat();
              navigate('/');
            }}
            className="flex items-center gap-2.5 text-left cursor-pointer"
          >
            <img
              src="/src/assets/images/avatar_nova_default_1794634324180.jpg"
              alt="NOVA AI"
              referrerPolicy="no-referrer"
              className="w-7 h-7 rounded-lg object-cover border border-zinc-300 dark:border-zinc-700 shrink-0"
            />
            <span className="font-display font-bold text-sm tracking-tight text-zinc-900 dark:text-white whitespace-nowrap">
              NOVA AI
            </span>
          </button>
        )}
        {isMobile ? (
          <button
            type="button"
            onClick={() => setMobileOpen(false)}
            aria-label="Close navigation"
            className="p-2 rounded-lg text-zinc-500 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-100 dark:hover:bg-zinc-800/70 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setCollapsed((c) => !c)}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            className="p-2 rounded-lg text-zinc-500 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-100 dark:hover:bg-zinc-800/70 cursor-pointer mx-auto"
          >
            {collapsed ? <PanelLeftOpen className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
          </button>
        )}
      </div>

      {/* New Chat Button */}
      <div className="p-3 shrink-0">
        <button
          type="button"
          onClick={() => {
            if (onNewChat) onNewChat();
            navigate('/');
            setMobileOpen(false);
          }}
          className={`w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-950 font-medium text-sm transition-colors cursor-pointer whitespace-nowrap ${
            collapsed && !isMobile ? 'px-0' : ''
          }`}
        >
          <Plus className="w-4 h-4 shrink-0" />
          {(!collapsed || isMobile) && <span>New Chat</span>}
        </button>
      </div>

      {/* Primary Modules (Simple & Clean) */}
      <nav className="px-2.5 space-y-0.5 shrink-0">
        {primaryNav.map((item) => {
          const Icon = item.icon;
          const active = item.matchPaths.includes(currentPath);
          return (
            <button
              key={item.path}
              type="button"
              onClick={() => {
                navigate(item.path);
                setMobileOpen(false);
              }}
              title={collapsed && !isMobile ? item.label : undefined}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                active
                  ? 'bg-zinc-200/80 dark:bg-zinc-800 text-zinc-950 dark:text-white'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-100 dark:hover:bg-zinc-800/50'
              } ${collapsed && !isMobile ? 'justify-center px-2' : ''}`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {(!collapsed || isMobile) && <span className="truncate">{item.label}</span>}
            </button>
          );
        })}

        {/* Collapsible More Tools with smooth animation */}
        {(!collapsed || isMobile) && (
          <div className="pt-1">
            <button
              type="button"
              onClick={() => setMoreOpen((o) => !o)}
              aria-expanded={showMore}
              className="w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-medium text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200 hover:bg-zinc-100/70 dark:hover:bg-zinc-800/40 transition-colors cursor-pointer"
            >
              <span>More</span>
              <motion.span
                animate={{ rotate: showMore ? 180 : 0 }}
                transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
                className="inline-flex items-center"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </motion.span>
            </button>
            <AnimatePresence initial={false}>
              {showMore && (
                <motion.div
                  key="sidebar-more-list"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
                  className="overflow-hidden"
                >
                  <div className="mt-0.5 space-y-0.5 pl-1 pb-1">
                    {secondaryNav.map((item, idx) => {
                      const Icon = item.icon;
                      const active = currentPath === item.path;
                      return (
                        <motion.button
                          key={item.path}
                          type="button"
                          initial={{ opacity: 0, x: -6 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.16, delay: idx * 0.025 }}
                          onClick={() => {
                            navigate(item.path);
                            setMobileOpen(false);
                          }}
                          className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                            active
                              ? 'bg-zinc-200/80 dark:bg-zinc-800 text-zinc-950 dark:text-white'
                              : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-100 dark:hover:bg-zinc-800/50'
                          }`}
                        >
                          <Icon className="w-3.5 h-3.5 shrink-0" />
                          <span className="truncate">{item.label}</span>
                        </motion.button>
                      );
                    })}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </nav>

      {/* Recent Chats */}
      {(!collapsed || isMobile) && (
        <div className="mt-3 pt-3 border-t border-zinc-200 dark:border-zinc-800/80 flex-1 min-h-0 flex flex-col px-3">
          <div className="relative mb-2 shrink-0">
            <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search chats..."
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg bg-zinc-100 dark:bg-[#141416] border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-zinc-200 placeholder:text-zinc-400 focus:outline-none focus:border-zinc-500"
            />
          </div>

          <div className="text-[11px] font-medium text-zinc-400 px-1 py-1 shrink-0">
            Recent chats
          </div>
          <div className="flex-1 overflow-y-auto space-y-0.5 pr-1 pb-2">
            {conversations.length === 0 ? (
              <p className="text-xs text-zinc-400 px-2 py-2">No chats yet.</p>
            ) : (
              conversations.slice(0, 25).map((conv) => {
                const isSelected = (currentPath === '/' || currentPath === '/chat') && activeConversationId === conv.id;
                return (
                  <div
                    key={conv.id}
                    onClick={() => {
                      if (onSelectConversation) onSelectConversation(conv.id);
                      navigate('/');
                      setMobileOpen(false);
                    }}
                    className={`group flex items-center justify-between gap-2 px-2.5 py-2 rounded-lg text-xs cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-zinc-200/80 dark:bg-zinc-800 text-zinc-950 dark:text-white font-medium'
                        : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/50 hover:text-zinc-900 dark:hover:text-zinc-200'
                    }`}
                  >
                    <span className="truncate flex-1">{conv.title}</span>
                    <button
                      type="button"
                      onClick={(e) => handleDeleteConversation(e, conv.id)}
                      aria-label="Delete conversation"
                      className="opacity-0 group-hover:opacity-100 p-1 rounded hover:text-red-400 transition-opacity cursor-pointer shrink-0"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Footer: User Account + Theme */}
      <div className="p-3 border-t border-zinc-200 dark:border-zinc-800/80 shrink-0">
        <div className={`flex items-center ${collapsed && !isMobile ? 'justify-center flex-col gap-2' : 'justify-between gap-2'}`}>
          <button
            type="button"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            aria-label="Toggle theme"
            title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            className="p-2 rounded-lg text-zinc-500 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-100 dark:hover:bg-zinc-800/70 transition-colors cursor-pointer"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {user && (
            <>
              {(!collapsed || isMobile) && (
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-semibold text-zinc-900 dark:text-white truncate">{user.name}</div>
                  <div className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate uppercase">
                    {user.plan}
                  </div>
                </div>
              )}
              <button
                type="button"
                onClick={async () => {
                  await logout();
                  if (onNewChat) onNewChat();
                  navigate('/');
                }}
                title="Sign out"
                aria-label="Sign out"
                className="p-2 rounded-lg text-zinc-500 hover:text-red-500 hover:bg-zinc-100 dark:hover:bg-zinc-800/70 transition-colors cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen w-full overflow-hidden bg-[#FAFAFA] dark:bg-[#09090B] text-zinc-900 dark:text-zinc-50">
      {/* Desktop Sidebar */}
      <aside
        className={`hidden md:block shrink-0 transition-all duration-200 ${
          collapsed ? 'w-[68px]' : 'w-[252px]'
        }`}
      >
        {sidebarContent(false)}
      </aside>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="fixed inset-0 z-50 md:hidden flex"
          >
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ duration: 0.24, ease: [0.22, 1, 0.36, 1] }}
              className="w-[264px] h-full shadow-2xl"
            >
              {sidebarContent(true)}
            </motion.div>
            <div className="flex-1 bg-black/60 backdrop-blur-xs" onClick={() => setMobileOpen(false)} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Viewport */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        {/* Mobile Header */}
        <header className="md:hidden flex items-center justify-between px-4 h-13 border-b border-zinc-200 dark:border-zinc-800/80 bg-white/90 dark:bg-[#0E0E11]/90 backdrop-blur-md shrink-0">
          <button
            type="button"
            onClick={() => setMobileOpen(true)}
            aria-label="Open navigation"
            className="p-2 -ml-2 rounded-lg text-zinc-700 dark:text-zinc-200 cursor-pointer"
          >
            <Menu className="w-5 h-5" />
          </button>
          <span className="font-display font-bold text-sm tracking-tight">NOVA AI</span>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              aria-label="Toggle theme"
              className="p-2 -mr-2 rounded-lg text-zinc-600 dark:text-zinc-300 cursor-pointer"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </header>

        <main className="flex-1 min-h-0 overflow-y-auto">{children}</main>
      </div>
    </div>
  );
}
