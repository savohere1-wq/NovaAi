import React, { useMemo, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import hljs from 'highlight.js';
import { Check, Code2, Copy } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
  onOpenInWorkspace?: (code: string, language: string) => void;
}

function CodeBlock({
  language,
  code,
  onOpenInWorkspace,
}: {
  language: string;
  code: string;
  onOpenInWorkspace?: (code: string, language: string) => void;
}) {
  const [copied, setCopied] = useState(false);

  const highlighted = useMemo(() => {
    try {
      if (language && hljs.getLanguage(language)) {
        return hljs.highlight(code, { language }).value;
      }
      return hljs.highlightAuto(code).value;
    } catch {
      return code;
    }
  }, [code, language]);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="my-3 rounded-xl overflow-hidden border border-zinc-200 dark:border-zinc-800 bg-[#0D0D0F]">
      <div className="flex items-center justify-between px-3.5 py-2 bg-[#141416] border-b border-zinc-800 text-xs text-zinc-400">
        <span className="font-mono lowercase">{language || 'code'}</span>
        <div className="flex items-center gap-2">
          {onOpenInWorkspace && (
            <button
              type="button"
              onClick={() => onOpenInWorkspace(code, language || 'html')}
              className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md hover:bg-white/10 text-zinc-300 hover:text-white transition-colors cursor-pointer"
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Open in Workspace</span>
            </button>
          )}
          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md hover:bg-white/10 text-zinc-300 hover:text-white transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>
      </div>
      <pre className="p-4 overflow-x-auto text-[13px] leading-relaxed font-mono">
        <code className="hljs" dangerouslySetInnerHTML={{ __html: highlighted }} />
      </pre>
    </div>
  );
}

export function MarkdownRenderer({ content, onOpenInWorkspace }: MarkdownRendererProps) {
  return (
    <div className="nova-prose text-zinc-800 dark:text-zinc-100 break-words">
      <ReactMarkdown
        remarkPlugins={[remarkGfm, remarkMath]}
        rehypePlugins={[rehypeKatex]}
        components={{
          code({ className, children, ...props }) {
            const match = /language-(\w+)/.exec(className || '');
            const codeString = String(children).replace(/\n$/, '');
            const isBlock = Boolean(match) || codeString.includes('\n');
            if (isBlock) {
              return (
                <CodeBlock
                  language={match?.[1] || 'text'}
                  code={codeString}
                  onOpenInWorkspace={onOpenInWorkspace}
                />
              );
            }
            return (
              <code className={className} {...props}>
                {children}
              </code>
            );
          },
          a({ href, children }) {
            return (
              <a href={href} target="_blank" rel="noopener noreferrer">
                {children}
              </a>
            );
          },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
