import React, { useCallback, useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  BookOpen,
  Globe,
  Loader2,
  Mic,
  MicOff,
  Phone,
  PhoneOff,
  Send,
  Volume2,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { apiFetch, getStoredToken } from '../../lib/api';
import { SUPPORTED_LANGUAGES, VOICE_PERSONAS } from '../../lib/languages';

interface CallTurn {
  id: string;
  role: 'user' | 'assistant';
  text: string;
}

interface LiveVoiceCallProps {
  initialLanguage?: string;
  initialLearningMode?: boolean;
  onClose?: () => void;
  embedded?: boolean;
}

function pcmFloat32ToBase64(float32: Float32Array): string {
  const buffer = new ArrayBuffer(float32.length * 2);
  const view = new DataView(buffer);
  for (let i = 0; i < float32.length; i++) {
    const s = Math.max(-1, Math.min(1, float32[i]));
    view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function base64ToPcmFloat32(base64: string): Float32Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  const view = new DataView(bytes.buffer);
  const sampleCount = Math.floor(bytes.byteLength / 2);
  const float32 = new Float32Array(sampleCount);
  for (let i = 0; i < sampleCount; i++) {
    float32[i] = view.getInt16(i * 2, true) / 0x8000;
  }
  return float32;
}

export function LiveVoiceCall({
  initialLanguage,
  initialLearningMode = false,
  onClose,
  embedded = false,
}: LiveVoiceCallProps) {
  const { preferences, updatePreferences, notify } = useAuth();
  const [voiceName, setVoiceName] = useState<string>(preferences.voiceName || 'Zephyr');
  const [language, setLanguage] = useState<string>(initialLanguage || preferences.language || 'auto');
  const [learningMode, setLearningMode] = useState<boolean>(initialLearningMode);

  const [status, setStatus] = useState<'idle' | 'connecting' | 'live' | 'error'>('idle');
  const [muted, setMuted] = useState(false);
  const [aiSpeaking, setAiSpeaking] = useState(false);
  const [micLevel, setMicLevel] = useState(0);
  const [callSeconds, setCallSeconds] = useState(0);
  const [statusNote, setStatusNote] = useState('');
  const [turns, setTurns] = useState<CallTurn[]>([]);
  const [textQuestion, setTextQuestion] = useState('');
  const [previewingVoice, setPreviewingVoice] = useState<string | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const inputCtxRef = useRef<AudioContext | null>(null);
  const outputCtxRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const activeSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const nextStartTimeRef = useRef<number>(0);
  const mutedRef = useRef<boolean>(false);
  const statusRef = useRef<'idle' | 'connecting' | 'live' | 'error'>('idle');
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);
  const transcriptEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    mutedRef.current = muted;
  }, [muted]);

  useEffect(() => {
    statusRef.current = status;
  }, [status]);

  useEffect(() => {
    if (status !== 'live') return;
    const id = window.setInterval(() => {
      setCallSeconds((s) => s + 1);
    }, 1000);
    return () => window.clearInterval(id);
  }, [status]);

  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [turns]);

  const stopOutputPlayback = useCallback(() => {
    for (const src of activeSourcesRef.current) {
      try {
        src.stop();
      } catch {
        // already stopped
      }
    }
    activeSourcesRef.current.clear();
    nextStartTimeRef.current = 0;
    setAiSpeaking(false);
  }, []);

  const cleanupCall = useCallback(() => {
    stopOutputPlayback();
    if (processorRef.current) {
      try {
        processorRef.current.disconnect();
      } catch {
        // ignore
      }
      processorRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (inputCtxRef.current) {
      void inputCtxRef.current.close().catch(() => {});
      inputCtxRef.current = null;
    }
    if (outputCtxRef.current) {
      void outputCtxRef.current.close().catch(() => {});
      outputCtxRef.current = null;
    }
    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch {
        // ignore
      }
      wsRef.current = null;
    }
    setMicLevel(0);
    setAiSpeaking(false);
  }, [stopOutputPlayback]);

  useEffect(() => {
    return () => {
      cleanupCall();
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
        previewAudioRef.current = null;
      }
    };
  }, [cleanupCall]);

  const playPcmChunk = useCallback((base64Audio: string) => {
    const ctx = outputCtxRef.current;
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      void ctx.resume();
    }
    const samples = base64ToPcmFloat32(base64Audio);
    if (samples.length === 0) return;

    const buffer = ctx.createBuffer(1, samples.length, 24000);
    buffer.getChannelData(0).set(samples);

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);

    const now = ctx.currentTime;
    const startAt = Math.max(nextStartTimeRef.current, now);
    source.start(startAt);
    nextStartTimeRef.current = startAt + buffer.duration;

    activeSourcesRef.current.add(source);
    setAiSpeaking(true);
    source.onended = () => {
      activeSourcesRef.current.delete(source);
      if (activeSourcesRef.current.size === 0) {
        setAiSpeaking(false);
      }
    };
  }, []);

  const appendTurnDelta = useCallback((role: 'user' | 'assistant', chunkText: string) => {
    const cleaned = chunkText;
    if (!cleaned) return;
    setTurns((prev) => {
      const last = prev[prev.length - 1];
      if (last && last.role === role) {
        return [...prev.slice(0, -1), { ...last, text: last.text + cleaned }];
      }
      return [...prev, { id: `${role}-${Date.now()}-${Math.random()}`, role, text: cleaned }];
    });
  }, []);

  const startCall = useCallback(
    async (override?: { voice?: string; lang?: string; learn?: boolean }) => {
      cleanupCall();
      const targetVoice = override?.voice ?? voiceName;
      const targetLang = override?.lang ?? language;
      const targetLearn = override?.learn ?? learningMode;

      setStatus('connecting');
      setStatusNote('Connecting live audio...');
      setCallSeconds(0);

      let micStream: MediaStream | null = null;
      try {
        micStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
        streamRef.current = micStream;
      } catch {
        setStatusNote('Mic blocked — connected in text-to-voice mode. Type below to talk!');
      }

      const inputCtx = new AudioContext({ sampleRate: 16000 });
      const outputCtx = new AudioContext({ sampleRate: 24000 });
      inputCtxRef.current = inputCtx;
      outputCtxRef.current = outputCtx;

      if (micStream) {
        const source = inputCtx.createMediaStreamSource(micStream);
        const processor = inputCtx.createScriptProcessor(4096, 1, 1);
        source.connect(processor);
        processor.connect(inputCtx.destination);
        processorRef.current = processor;

        processor.onaudioprocess = (e) => {
          const ws = wsRef.current;
          if (!ws || ws.readyState !== WebSocket.OPEN || statusRef.current !== 'live' || mutedRef.current) {
            setMicLevel(0);
            return;
          }
          const data = e.inputBuffer.getChannelData(0);
          let sum = 0;
          for (let i = 0; i < data.length; i++) {
            sum += data[i] * data[i];
          }
          const rms = Math.sqrt(sum / data.length);
          setMicLevel(Math.min(1, rms * 8));

          const b64 = pcmFloat32ToBase64(data);
          ws.send(JSON.stringify({ type: 'audio', audio: b64 }));
        };
      }

      const token = getStoredToken();
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const qs = new URLSearchParams({
        voice: targetVoice,
        language: targetLang,
        learningMode: targetLearn ? '1' : '0',
      });
      if (token) qs.set('token', token);

      const ws = new WebSocket(`${proto}//${window.location.host}/api/live-voice?${qs.toString()}`);
      wsRef.current = ws;

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data as string) as {
            type: string;
            audio?: string;
            text?: string;
            message?: string;
          };
          if (msg.type === 'ready') {
            setStatus('live');
            setStatusNote(micStream ? 'Listening — ask any question' : 'Connected — type below to hear NOVA answer');
          } else if (msg.type === 'audio' && msg.audio) {
            playPcmChunk(msg.audio);
          } else if (msg.type === 'input_transcript' && msg.text) {
            appendTurnDelta('user', msg.text);
          } else if (msg.type === 'output_transcript' && msg.text) {
            appendTurnDelta('assistant', msg.text);
          } else if (msg.type === 'interrupted') {
            stopOutputPlayback();
          } else if (msg.type === 'error') {
            setStatus('error');
            setStatusNote(msg.message || 'Live voice connection failed.');
            notify(msg.message || 'Live voice error', 'error');
          } else if (msg.type === 'closed') {
            if (statusRef.current === 'live') {
              setStatus('idle');
              setStatusNote('Call ended');
            }
          }
        } catch {
          // ignore malformed event
        }
      };

      ws.onerror = () => {
        setStatus('error');
        setStatusNote('WebSocket audio stream disconnected.');
      };

      ws.onclose = () => {
        if (statusRef.current === 'live' || statusRef.current === 'connecting') {
          setStatus('idle');
          cleanupCall();
        }
      };
    },
    [appendTurnDelta, cleanupCall, language, learningMode, notify, playPcmChunk, stopOutputPlayback, voiceName]
  );

  const endCall = () => {
    setStatus('idle');
    setStatusNote('');
    cleanupCall();
  };

  const handleVoiceChange = (nextVoice: string) => {
    setVoiceName(nextVoice);
    void updatePreferences({ voiceName: nextVoice });
    if (status === 'live' || status === 'connecting') {
      void startCall({ voice: nextVoice });
    }
  };

  const handleLanguageChange = (nextLang: string) => {
    setLanguage(nextLang);
    if (status === 'live' || status === 'connecting') {
      void startCall({ lang: nextLang });
    }
  };

  const handleLearningToggle = () => {
    const next = !learningMode;
    setLearningMode(next);
    if (status === 'live' || status === 'connecting') {
      void startCall({ learn: next });
    }
  };

  const handlePreviewVoice = async (v: string) => {
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
      previewAudioRef.current = null;
    }
    setPreviewingVoice(v);
    try {
      const res = await apiFetch<{ audioBase64: string; mimeType: string }>('/api/voice/tts', {
        method: 'POST',
        body: JSON.stringify({
          text: `Hi there! I am ${v}, ready to answer your questions and help you learn any language!`,
          voiceName: v,
        }),
      });
      const audio = new Audio(`data:${res.mimeType};base64,${res.audioBase64}`);
      previewAudioRef.current = audio;
      await audio.play();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Unable to preview voice', 'error');
    } finally {
      setPreviewingVoice(null);
    }
  };

  const sendTextInCall = (e: React.FormEvent) => {
    e.preventDefault();
    const q = textQuestion.trim();
    if (!q || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    setTextQuestion('');
    setTurns((prev) => [...prev, { id: `u-txt-${Date.now()}`, role: 'user', text: q }]);
    wsRef.current.send(JSON.stringify({ type: 'text', text: q }));
  };

  const formatDuration = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const orbScale = status === 'live' ? 1 + (aiSpeaking ? 0.16 : micLevel * 0.25) : 1;

  return (
    <div
      className={`flex flex-col ${
        embedded ? 'h-full' : 'max-h-[90vh] w-full max-w-2xl rounded-2xl border border-zinc-800 bg-[#0E0E11] shadow-2xl overflow-hidden'
      } bg-[#09090B] text-zinc-50`}
    >
      {/* Header */}
      <div className="px-5 py-4 border-b border-zinc-800/80 flex items-center justify-between gap-3 shrink-0">
        <div>
          <h2 className="font-display text-base font-bold tracking-tight text-white">
            Live Voice Call
          </h2>
          <p className="text-xs text-zinc-400">
            Real-time Q&amp;A across 5 voices and all languages
          </p>
        </div>

        <div className="flex items-center gap-2">
          {status === 'live' && (
            <span className="text-xs font-mono tabular-nums text-zinc-300 px-2 py-1 rounded-md bg-zinc-900 border border-zinc-800">
              {formatDuration(callSeconds)}
            </span>
          )}
          {onClose && (
            <button
              type="button"
              onClick={() => {
                endCall();
                onClose();
              }}
              aria-label="Close voice call"
              className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800/70 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Controls Strip: Voice Picker + All Languages + Language Tutor */}
      <div className="px-5 py-3 border-b border-zinc-800/70 bg-[#0E0E11] flex flex-wrap items-center gap-2.5 shrink-0">
        <div className="flex items-center gap-1.5 flex-1 min-w-[160px]">
          <Volume2 className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
          <select
            value={voiceName}
            onChange={(e) => handleVoiceChange(e.target.value)}
            aria-label="Select Voice"
            className="w-full px-2.5 py-1.5 rounded-lg bg-[#141416] border border-zinc-800 text-xs text-white focus:outline-none focus:border-zinc-500 cursor-pointer"
          >
            {VOICE_PERSONAS.map((v) => (
              <option key={v.id} value={v.id}>
                {v.name} — {v.tagline}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => void handlePreviewVoice(voiceName)}
            disabled={previewingVoice !== null}
            title="Hear a sample of this voice"
            className="px-2.5 py-1.5 rounded-lg border border-zinc-800 hover:bg-zinc-800 text-xs text-zinc-300 shrink-0 cursor-pointer"
          >
            {previewingVoice === voiceName ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Sample'}
          </button>
        </div>

        <div className="flex items-center gap-1.5 flex-1 min-w-[160px]">
          <Globe className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
          <select
            value={language}
            onChange={(e) => handleLanguageChange(e.target.value)}
            aria-label="Select Language"
            className="w-full px-2.5 py-1.5 rounded-lg bg-[#141416] border border-zinc-800 text-xs text-white focus:outline-none focus:border-zinc-500 cursor-pointer"
          >
            {SUPPORTED_LANGUAGES.map((l) => (
              <option key={l.code} value={l.code}>
                {l.label}
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={handleLearningToggle}
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer whitespace-nowrap ${
            learningMode
              ? 'bg-white text-zinc-950 border-white'
              : 'border-zinc-800 text-zinc-300 hover:bg-zinc-800/70'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>Language Tutor</span>
        </button>
      </div>

      {/* Central Interactive Orb + Live Captions */}
      <div className="flex-1 min-h-0 overflow-y-auto px-5 py-6 flex flex-col items-center">
        <div className="my-4 flex flex-col items-center">
          <div className="relative flex items-center justify-center w-40 h-40">
            <motion.div
              animate={{
                scale: status === 'live' ? [1, 1.15, 1] : 1,
                opacity: status === 'live' ? [0.25, 0.5, 0.25] : 0.15,
              }}
              transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute inset-0 rounded-full border border-zinc-500/40"
            />
            <motion.div
              animate={{ scale: orbScale }}
              transition={{ type: 'spring', stiffness: 260, damping: 20 }}
              className={`w-28 h-28 rounded-full flex items-center justify-center border transition-colors ${
                status === 'live'
                  ? aiSpeaking
                    ? 'bg-white text-zinc-950 border-white shadow-[0_0_40px_rgba(255,255,255,0.2)]'
                    : 'bg-zinc-900 text-white border-zinc-500'
                  : 'bg-[#141416] text-zinc-400 border-zinc-800'
              }`}
            >
              {status === 'connecting' ? (
                <Loader2 className="w-8 h-8 animate-spin" />
              ) : (
                <img
                  src="/src/assets/images/avatar_nova_default_1794634324180.jpg"
                  alt="NOVA AI"
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 rounded-full object-cover"
                />
              )}
            </motion.div>
          </div>

          <div className="mt-3 text-center">
            <div className="text-sm font-medium text-white">
              {status === 'idle' && `Ready to call with ${voiceName}`}
              {status === 'connecting' && 'Connecting live voice...'}
              {status === 'live' && (aiSpeaking ? `${voiceName} is speaking...` : muted ? 'Microphone muted' : 'Listening to you...')}
              {status === 'error' && 'Connection interrupted'}
            </div>
            {statusNote && <p className="text-xs text-zinc-400 mt-1 max-w-md">{statusNote}</p>}
          </div>
        </div>

        {/* Live Transcripts */}
        {turns.length > 0 && (
          <div className="w-full max-w-xl mt-4 space-y-3 border-t border-zinc-800/80 pt-4">
            <AnimatePresence initial={false}>
              {turns.map((turn) => (
                <motion.div
                  key={turn.id}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.18 }}
                  className={`flex flex-col ${turn.role === 'user' ? 'items-end' : 'items-start'}`}
                >
                  {turn.role === 'user' ? (
                    <div className="max-w-[85%] rounded-2xl px-3.5 py-2 bg-zinc-800 text-zinc-100 text-xs leading-relaxed">
                      {turn.text}
                    </div>
                  ) : (
                    <div className="w-full text-sm text-zinc-200 leading-relaxed">
                      <span className="text-[11px] font-medium text-zinc-400 block mb-0.5">{voiceName}</span>
                      {turn.text}
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
            <div ref={transcriptEndRef} />
          </div>
        )}
      </div>

      {/* Bottom Call Controls + Optional Text Prompt Inside Call */}
      <div className="p-4 border-t border-zinc-800/80 bg-[#0E0E11] space-y-3 shrink-0">
        {status === 'live' && (
          <form onSubmit={sendTextInCall} className="flex items-center gap-2 max-w-xl mx-auto">
            <input
              type="text"
              value={textQuestion}
              onChange={(e) => setTextQuestion(e.target.value)}
              placeholder="Or type a question for NOVA to answer aloud..."
              className="flex-1 px-3 py-2 rounded-xl bg-[#09090B] border border-zinc-800 text-xs text-white placeholder:text-zinc-500 focus:outline-none focus:border-zinc-500"
            />
            <button
              type="submit"
              disabled={!textQuestion.trim()}
              className="p-2 rounded-xl bg-white text-zinc-950 disabled:opacity-35 cursor-pointer"
              aria-label="Send question in call"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        )}

        <div className="flex items-center justify-center gap-3">
          {status === 'live' || status === 'connecting' ? (
            <>
              <button
                type="button"
                onClick={() => setMuted((m) => !m)}
                className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border text-xs font-medium transition-colors cursor-pointer ${
                  muted
                    ? 'bg-zinc-800 border-zinc-700 text-zinc-200'
                    : 'bg-[#141416] border-zinc-800 text-white hover:bg-zinc-800'
                }`}
              >
                {muted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                <span>{muted ? 'Unmute' : 'Mute'}</span>
              </button>

              <button
                type="button"
                onClick={endCall}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                <PhoneOff className="w-4 h-4" />
                <span>End Call</span>
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={() => void startCall()}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 text-sm font-semibold transition-colors cursor-pointer"
            >
              <Phone className="w-4 h-4" />
              <span>Start Live Voice Call</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
