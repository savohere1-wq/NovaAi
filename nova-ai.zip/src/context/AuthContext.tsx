import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { apiFetch, setStoredToken } from '../lib/api';
import type { AIModelInfo, ThemeMode, UserPreferences, UserProfile } from '../types/nova';

interface ToastItem {
  id: string;
  type: 'info' | 'success' | 'error';
  message: string;
}

interface AuthContextValue {
  user: UserProfile | null;
  preferences: UserPreferences;
  models: AIModelInfo[];
  loading: boolean;
  theme: ThemeMode;
  setTheme: (mode: ThemeMode) => void;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshAuth: () => Promise<void>;
  updatePreferences: (patch: Partial<UserPreferences>) => Promise<void>;
  notify: (message: string, type?: 'info' | 'success' | 'error') => void;
}

const DEFAULT_PREFS: UserPreferences = {
  theme: 'dark',
  defaultModel: 'gemini-3.1-flash-lite',
  language: 'en',
  memoryEnabled: true,
  thinkingMode: 'low',
  voiceName: 'Kore',
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [preferences, setPreferences] = useState<UserPreferences>(DEFAULT_PREFS);
  const [models, setModels] = useState<AIModelInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    try {
      return localStorage.getItem('nova_theme') === 'light' ? 'light' : 'dark';
    } catch {
      return 'dark';
    }
  });

  const applyThemeClass = useCallback((mode: ThemeMode) => {
    setThemeState(mode);
    try {
      localStorage.setItem('nova_theme', mode);
    } catch {
      // ignore
    }
    if (mode === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  const notify = useCallback((message: string, type: 'info' | 'success' | 'error' = 'info') => {
    const id = Math.random().toString(36).slice(2);
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4200);
  }, []);

  const setTheme = useCallback(
    (mode: ThemeMode) => {
      applyThemeClass(mode);
      if (user) {
        apiFetch('/api/preferences', {
          method: 'PATCH',
          body: JSON.stringify({ theme: mode }),
        }).catch(() => {});
      }
    },
    [applyThemeClass, user]
  );

  const refreshAuth = useCallback(async () => {
    try {
      const [modelsRes, meRes] = await Promise.all([
        apiFetch<{ models: AIModelInfo[] }>('/api/models').catch(() => ({ models: [] })),
        apiFetch<{ user: UserProfile; preferences: UserPreferences }>('/api/auth/me').catch(() => null),
      ]);
      setModels(modelsRes.models || []);
      if (meRes?.user) {
        setUser(meRes.user);
        setPreferences(meRes.preferences || DEFAULT_PREFS);
        if (meRes.preferences?.theme) {
          applyThemeClass(meRes.preferences.theme);
        }
      } else {
        setUser(null);
      }
    } finally {
      setLoading(false);
    }
  }, [applyThemeClass]);

  useEffect(() => {
    void refreshAuth();
  }, [refreshAuth]);

  const login = async (email: string, password: string) => {
    const data = await apiFetch<{ user: UserProfile; preferences: UserPreferences; token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    setStoredToken(data.token);
    setUser(data.user);
    setPreferences(data.preferences);
    applyThemeClass(data.preferences.theme);
  };

  const register = async (name: string, email: string, password: string) => {
    const data = await apiFetch<{ user: UserProfile; preferences: UserPreferences; token: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    });
    setStoredToken(data.token);
    setUser(data.user);
    setPreferences(data.preferences);
    applyThemeClass(data.preferences.theme);
  };

  const logout = async () => {
    await apiFetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
    setStoredToken(null);
    setUser(null);
  };

  const updatePreferences = async (patch: Partial<UserPreferences>) => {
    const data = await apiFetch<{ preferences: UserPreferences }>('/api/preferences', {
      method: 'PATCH',
      body: JSON.stringify(patch),
    });
    setPreferences(data.preferences);
    if (patch.theme) {
      applyThemeClass(patch.theme);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        preferences,
        models,
        loading,
        theme,
        setTheme,
        login,
        register,
        logout,
        refreshAuth,
        updatePreferences,
        notify,
      }}
    >
      {children}
      {/* Toast Notification Stack */}
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`pointer-events-auto px-4 py-3 rounded-xl border text-sm font-medium shadow-lg backdrop-blur-md transition-all ${
              t.type === 'error'
                ? 'bg-red-950/95 border-red-500/40 text-red-100'
                : t.type === 'success'
                ? 'bg-emerald-950/95 border-emerald-500/40 text-emerald-100'
                : 'bg-white/95 dark:bg-[#141416]/95 border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white'
            }`}
          >
            {t.message}
          </div>
        ))}
      </div>
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
