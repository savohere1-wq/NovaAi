const TOKEN_KEY = 'nova_auth_token';

let memoryToken: string | null = null;
try {
  memoryToken = sessionStorage.getItem(TOKEN_KEY);
} catch {
  memoryToken = null;
}

export function setStoredToken(token: string | null) {
  memoryToken = token;
  try {
    if (token) {
      sessionStorage.setItem(TOKEN_KEY, token);
    } else {
      sessionStorage.removeItem(TOKEN_KEY);
    }
  } catch {
    // ignore storage restriction
  }
}

export function getStoredToken(): string | null {
  return memoryToken;
}

export class ApiError extends Error {
  status: number;
  code?: string;
  data?: Record<string, unknown>;

  constructor(message: string, status: number, code?: string, data?: Record<string, unknown>) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.data = data;
  }
}

export async function apiFetch<T = unknown>(
  url: string,
  options: RequestInit = {}
): Promise<T> {
  const headers = new Headers(options.headers || {});
  if (memoryToken && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${memoryToken}`);
  }
  if (!(options.body instanceof FormData) && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const resp = await fetch(url, {
    ...options,
    headers,
    credentials: 'include',
  });

  if (!resp.ok) {
    let errMessage = `Request failed (${resp.status})`;
    let errCode: string | undefined;
    let errData: Record<string, unknown> | undefined;
    try {
      const data = (await resp.json()) as Record<string, unknown>;
      errData = data;
      errCode = typeof data.code === 'string' ? data.code : undefined;
      errMessage =
        (typeof data.error === 'string' && data.error) ||
        (typeof data.message === 'string' && data.message) ||
        errMessage;
    } catch {
      // keep default message
    }
    throw new ApiError(errMessage, resp.status, errCode, errData);
  }

  return (await resp.json()) as T;
}

export async function apiStreamPost(
  url: string,
  body: unknown,
  onEvent: (event: Record<string, unknown>) => void,
  signal?: AbortSignal
): Promise<void> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (memoryToken) {
    headers['Authorization'] = `Bearer ${memoryToken}`;
  }

  const resp = await fetch(url, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
    credentials: 'include',
    signal,
  });

  if (!resp.ok || !resp.body) {
    let errMessage = `Stream failed (${resp.status})`;
    let errCode: string | undefined;
    let errData: Record<string, unknown> | undefined;
    try {
      const data = (await resp.json()) as Record<string, unknown>;
      errData = data;
      errCode = typeof data.code === 'string' ? data.code : undefined;
      if (typeof data.error === 'string' && data.error) errMessage = data.error;
    } catch {
      // ignore
    }
    throw new ApiError(errMessage, resp.status, errCode, errData);
  }

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  const emitChunk = (chunkText: string) => {
    const normalized = chunkText.replace(/\r\n/g, '\n');
    buffer += normalized;
    const parts = buffer.split('\n\n');
    buffer = parts.pop() ?? '';
    for (const part of parts) {
      const lines = part.split('\n');
      for (const line of lines) {
        if (line.startsWith('data: ')) {
          try {
            const parsed = JSON.parse(line.slice(6)) as Record<string, unknown>;
            onEvent(parsed);
          } catch {
            // ignore malformed event
          }
        }
      }
    }
  };

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    emitChunk(decoder.decode(value, { stream: true }));
  }

  // Flush remaining decoded bytes and trailing SSE block if stream closed without double newline
  const trailing = decoder.decode();
  if (trailing || buffer.trim()) {
    emitChunk(trailing + '\n\n');
  }
}
