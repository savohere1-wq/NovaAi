export interface LanguageOption {
  code: string;
  label: string;
  nativeLabel: string;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'auto', label: 'All Languages (Auto-Detect)', nativeLabel: 'Auto' },
  { code: 'en', label: 'English', nativeLabel: 'English' },
  { code: 'hi', label: 'Hindi', nativeLabel: 'हिन्दी' },
  { code: 'hinglish', label: 'Hinglish', nativeLabel: 'Hinglish' },
  { code: 'es', label: 'Spanish', nativeLabel: 'Español' },
  { code: 'fr', label: 'French', nativeLabel: 'Français' },
  { code: 'de', label: 'German', nativeLabel: 'Deutsch' },
  { code: 'ja', label: 'Japanese', nativeLabel: '日本語' },
  { code: 'ko', label: 'Korean', nativeLabel: '한국어' },
  { code: 'zh', label: 'Mandarin Chinese', nativeLabel: '中文' },
  { code: 'ar', label: 'Arabic', nativeLabel: 'العربية' },
  { code: 'pt', label: 'Portuguese', nativeLabel: 'Português' },
  { code: 'it', label: 'Italian', nativeLabel: 'Italiano' },
  { code: 'ru', label: 'Russian', nativeLabel: 'Русский' },
  { code: 'bn', label: 'Bengali', nativeLabel: 'বাংলা' },
  { code: 'ta', label: 'Tamil', nativeLabel: 'தமிழ்' },
  { code: 'te', label: 'Telugu', nativeLabel: 'తెలుగు' },
  { code: 'mr', label: 'Marathi', nativeLabel: 'मराठी' },
  { code: 'ur', label: 'Urdu', nativeLabel: 'اردو' },
  { code: 'tr', label: 'Turkish', nativeLabel: 'Türkçe' },
  { code: 'nl', label: 'Dutch', nativeLabel: 'Nederlands' },
  { code: 'pl', label: 'Polish', nativeLabel: 'Polski' },
  { code: 'vi', label: 'Vietnamese', nativeLabel: 'Tiếng Việt' },
  { code: 'th', label: 'Thai', nativeLabel: 'ไทย' },
  { code: 'id', label: 'Indonesian', nativeLabel: 'Bahasa Indonesia' },
];

export function getLanguageLabel(code?: string): string {
  if (!code || code === 'auto') return 'All Languages (Auto-Detect)';
  const found = SUPPORTED_LANGUAGES.find((l) => l.code === code);
  return found ? found.label : code;
}

export interface VoicePersonaOption {
  id: 'Zephyr' | 'Kore' | 'Puck' | 'Charon' | 'Fenrir';
  name: string;
  tagline: string;
}

export const VOICE_PERSONAS: VoicePersonaOption[] = [
  { id: 'Zephyr', name: 'Zephyr', tagline: 'Bright, upbeat & friendly' },
  { id: 'Kore', name: 'Kore', tagline: 'Warm, calm & expressive' },
  { id: 'Puck', name: 'Puck', tagline: 'Energetic, playful & curious' },
  { id: 'Charon', name: 'Charon', tagline: 'Deep, steady & authoritative' },
  { id: 'Fenrir', name: 'Fenrir', tagline: 'Crisp, confident & dynamic' },
];
