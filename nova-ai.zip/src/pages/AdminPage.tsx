import React, { useEffect, useState } from 'react';
import { Loader2, Save, Shield } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import type { PlanTier, ProviderStatus, UserRole } from '../types/nova';

interface AdminUserRow {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  plan: PlanTier;
  created_at: string;
}

interface AdminOverview {
  users: AdminUserRow[];
  providers: ProviderStatus[];
  usageTotals: { totalRequests: number; totalTokens: number; avgLatencyMs: number };
  errorLogs: Array<{ id: string; route: string; error_message: string; severity: string; created_at: string }>;
  auditLogs: Array<{ id: string; adminEmail: string; action: string; target: string; created_at: string }>;
  settings: {
    allowRegistrations: boolean;
    freeDailyMessages: number;
    proDailyMessages: number;
    premiumDailyMessages: number;
    freeMonthlyImages: number;
    proMonthlyImages: number;
    premiumMonthlyImages: number;
  };
  storageBytes: number;
}

export function AdminPage() {
  const { user, notify } = useAuth();
  const [data, setData] = useState<AdminOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [savingSettings, setSavingSettings] = useState(false);

  const load = async () => {
    try {
      const res = await apiFetch<AdminOverview>('/api/admin/overview');
      setData(res);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Admin access denied', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const handleUpdateUser = async (id: string, patch: { role?: UserRole; plan?: PlanTier }) => {
    try {
      await apiFetch(`/api/admin/users/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(patch),
      });
      await load();
      notify('User updated and audit logged', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Update failed', 'error');
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!data) return;
    setSavingSettings(true);
    try {
      await apiFetch('/api/admin/settings', {
        method: 'PATCH',
        body: JSON.stringify(data.settings),
      });
      await load();
      notify('Platform settings saved', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to save settings', 'error');
    } finally {
      setSavingSettings(false);
    }
  };

  if (user?.role !== 'admin') {
    return (
      <div className="p-10 max-w-xl mx-auto text-center">
        <Shield className="w-10 h-10 mx-auto mb-3 text-red-500" />
        <h1 className="font-display text-xl font-bold">Administrator Access Required</h1>
        <p className="mt-2 text-sm text-slate-500">
          This route is verified server-side. Your current account does not hold administrator privileges.
        </p>
      </div>
    );
  }

  if (loading || !data) {
    return (
      <div className="p-10 flex items-center justify-center text-slate-500">
        <Loader2 className="w-5 h-5 animate-spin mr-2" />
        <span>Loading administration telemetry...</span>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight">Admin Control Panel</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Server-verified RBAC · User & Plan Management · AI Provider Readiness · Error & Audit Telemetry
        </p>
      </div>

      {/* Top Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-5">
          <div className="text-xs text-slate-500">Registered Users</div>
          <div className="mt-1 font-display text-2xl font-bold tabular-nums">{data.users.length}</div>
        </div>
        <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-5">
          <div className="text-xs text-slate-500">Total AI Requests</div>
          <div className="mt-1 font-display text-2xl font-bold tabular-nums">{data.usageTotals.totalRequests}</div>
        </div>
        <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-5">
          <div className="text-xs text-slate-500">Total Tokens Processed</div>
          <div className="mt-1 font-display text-2xl font-bold tabular-nums">
            {data.usageTotals.totalTokens.toLocaleString()}
          </div>
        </div>
        <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-5">
          <div className="text-xs text-slate-500">Database Storage</div>
          <div className="mt-1 font-display text-2xl font-bold tabular-nums">
            {(data.storageBytes / 1024).toFixed(1)} KB
          </div>
        </div>
      </div>

      {/* Provider Configuration Matrix */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-5">
        <h2 className="font-display text-sm font-semibold mb-4">AI Provider Status (Server Environment)</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {data.providers.map((p) => (
            <div key={p.id} className="p-4 rounded-xl bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/[0.06]">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span>{p.name}</span>
                <span className={p.configured ? 'text-emerald-500' : 'text-slate-400'}>
                  {p.configured ? 'Configured' : 'Not Set'}
                </span>
              </div>
              <div className="mt-1 text-[11px] font-mono text-slate-500">{p.envVar}</div>
              <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">{p.notes}</p>
            </div>
          ))}
        </div>
      </div>

      {/* User Management */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-5">
        <h2 className="font-display text-sm font-semibold mb-4">User & Subscription Management</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-white/[0.08] text-slate-500">
                <th className="py-2 text-left font-medium">Name</th>
                <th className="py-2 text-left font-medium">Email</th>
                <th className="py-2 text-left font-medium">Role</th>
                <th className="py-2 text-left font-medium">Plan</th>
                <th className="py-2 text-right font-medium">Joined</th>
              </tr>
            </thead>
            <tbody>
              {data.users.map((u) => (
                <tr key={u.id} className="border-b border-slate-100 dark:border-white/[0.04]">
                  <td className="py-2.5 font-medium">{u.name}</td>
                  <td className="py-2.5 font-mono text-slate-500">{u.email}</td>
                  <td className="py-2.5">
                    <select
                      value={u.role}
                      onChange={(e) => void handleUpdateUser(u.id, { role: e.target.value as UserRole })}
                      className="px-2 py-1 rounded-md bg-slate-100 dark:bg-[#09090B] border border-slate-200 dark:border-white/10"
                    >
                      <option value="user">user</option>
                      <option value="admin">admin</option>
                    </select>
                  </td>
                  <td className="py-2.5">
                    <select
                      value={u.plan}
                      onChange={(e) => void handleUpdateUser(u.id, { plan: e.target.value as PlanTier })}
                      className="px-2 py-1 rounded-md bg-slate-100 dark:bg-[#09090B] border border-slate-200 dark:border-white/10"
                    >
                      <option value="free">free</option>
                      <option value="pro">pro</option>
                      <option value="premium">premium</option>
                    </select>
                  </td>
                  <td className="py-2.5 text-right font-mono tabular-nums text-slate-500">
                    {new Date(u.created_at).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Platform Quota Settings */}
      <form
        onSubmit={handleSaveSettings}
        className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-5 space-y-4"
      >
        <div className="flex items-center justify-between">
          <h2 className="font-display text-sm font-semibold">Platform Limits & Registration</h2>
          <label className="inline-flex items-center gap-2 text-xs cursor-pointer">
            <input
              type="checkbox"
              checked={data.settings.allowRegistrations}
              onChange={(e) =>
                setData({
                  ...data,
                  settings: { ...data.settings, allowRegistrations: e.target.checked },
                })
              }
            />
            <span>Allow New Signups</span>
          </label>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="block text-slate-500 mb-1">Free Daily Messages</label>
            <input
              type="number"
              value={data.settings.freeDailyMessages}
              onChange={(e) =>
                setData({
                  ...data,
                  settings: { ...data.settings, freeDailyMessages: Number(e.target.value) },
                })
              }
              className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/10 font-mono"
            />
          </div>
          <div>
            <label className="block text-slate-500 mb-1">Pro Daily Messages</label>
            <input
              type="number"
              value={data.settings.proDailyMessages}
              onChange={(e) =>
                setData({
                  ...data,
                  settings: { ...data.settings, proDailyMessages: Number(e.target.value) },
                })
              }
              className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/10 font-mono"
            />
          </div>
          <div>
            <label className="block text-slate-500 mb-1">Free Monthly Visuals</label>
            <input
              type="number"
              value={data.settings.freeMonthlyImages}
              onChange={(e) =>
                setData({
                  ...data,
                  settings: { ...data.settings, freeMonthlyImages: Number(e.target.value) },
                })
              }
              className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/10 font-mono"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={savingSettings}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-950 text-xs font-medium cursor-pointer"
        >
          {savingSettings ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
          <span>Save Platform Settings</span>
        </button>
      </form>

      {/* Error & Audit Logs */}
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-5">
          <h2 className="font-display text-sm font-semibold mb-3">Recent Error Logs</h2>
          {data.errorLogs.length === 0 ? (
            <p className="text-xs text-slate-500">No errors logged.</p>
          ) : (
            <div className="space-y-2 max-h-60 overflow-y-auto text-xs">
              {data.errorLogs.map((err) => (
                <div key={err.id} className="p-2.5 rounded-lg bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/[0.05]">
                  <div className="font-mono text-red-500">{err.route}</div>
                  <div className="text-slate-600 dark:text-slate-300 mt-0.5">{err.error_message}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-5">
          <h2 className="font-display text-sm font-semibold mb-3">Admin Audit Trail</h2>
          {data.auditLogs.length === 0 ? (
            <p className="text-xs text-slate-500">No administrative actions recorded yet.</p>
          ) : (
            <div className="space-y-2 max-h-60 overflow-y-auto text-xs">
              {data.auditLogs.map((log) => (
                <div key={log.id} className="p-2.5 rounded-lg bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/[0.05]">
                  <div className="font-medium">{log.action}</div>
                  <div className="text-slate-500 font-mono text-[11px]">
                    {log.adminEmail} · {log.target}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
