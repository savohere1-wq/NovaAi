import React, { useState } from 'react';
import { motion } from 'motion/react';
import { KeyRound, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../lib/api';

interface AuthPageProps {
  initialMode: 'login' | 'register';
  navigate: (path: string) => void;
}

export function AuthPage({ initialMode, navigate }: AuthPageProps) {
  const { login, register, notify } = useAuth();
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>(initialMode);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [generatedToken, setGeneratedToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      if (mode === 'login') {
        await login(email, password);
        notify('Signed in to NOVA AI', 'success');
        navigate('/');
      } else if (mode === 'register') {
        await register(name, email, password);
        notify('Account created successfully', 'success');
        navigate('/');
      } else if (mode === 'forgot') {
        if (!generatedToken) {
          const res = await apiFetch<{ message: string; resetToken?: string }>('/api/auth/forgot-password', {
            method: 'POST',
            body: JSON.stringify({ email }),
          });
          notify(res.message, 'info');
          if (res.resetToken) {
            setGeneratedToken(res.resetToken);
            setResetToken(res.resetToken);
          }
        } else {
          const res = await apiFetch<{ message: string }>('/api/auth/reset-password', {
            method: 'POST',
            body: JSON.stringify({ token: resetToken, newPassword }),
          });
          notify(res.message, 'success');
          setGeneratedToken('');
          setMode('login');
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFAFA] dark:bg-[#09090B] text-zinc-900 dark:text-zinc-50 flex flex-col justify-center px-6 py-12">
      <motion.div
        initial={{ opacity: 0, y: 14, scale: 0.985 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
        className="max-w-md w-full mx-auto"
      >
        <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-8 shadow-sm">
          <div className="flex items-center gap-3 mb-6">
            <img
              src="/src/assets/images/avatar_nova_default_1794634324180.jpg"
              alt="NOVA AI"
              referrerPolicy="no-referrer"
              className="w-9 h-9 rounded-xl object-cover border border-zinc-200 dark:border-zinc-700"
            />
            <div>
              <h1 className="font-display text-xl font-bold tracking-tight">
                {mode === 'login'
                  ? 'Sign in to NOVA AI'
                  : mode === 'register'
                  ? 'Create your NOVA AI account'
                  : 'Reset your password'}
              </h1>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                {mode === 'login'
                  ? 'Sign in to start chatting and access your workspace.'
                  : mode === 'register'
                  ? 'Create an account to access chat, documents, and studio.'
                  : 'Generate a recovery token to reset your password.'}
              </p>
            </div>
          </div>

          {mode !== 'forgot' && (
            <div className="grid grid-cols-2 gap-1 p-1 mb-5 rounded-xl bg-zinc-100 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800">
              <button
                type="button"
                onClick={() => {
                  setError('');
                  setMode('login');
                }}
                className={`py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  mode === 'login'
                    ? 'bg-white dark:bg-[#1E1E22] text-zinc-900 dark:text-white shadow-xs'
                    : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setError('');
                  setMode('register');
                }}
                className={`py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  mode === 'register'
                    ? 'bg-white dark:bg-[#1E1E22] text-zinc-900 dark:text-white shadow-xs'
                    : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200'
                }`}
              >
                Register
              </button>
            </div>
          )}

          {error && (
            <div className="mb-4 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/30 text-sm text-red-600 dark:text-red-300">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-300 mb-1.5">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Alex Mercer"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-sm focus:outline-none focus:border-zinc-500 dark:focus:border-zinc-400"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-300 mb-1.5">
                Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@domain.com"
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-sm focus:outline-none focus:border-zinc-500 dark:focus:border-zinc-400"
              />
            </div>

            {mode !== 'forgot' && (
              <div>
                <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-300 mb-1.5">
                  Password
                </label>
                <input
                  type="password"
                  required
                  minLength={8}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 8 characters"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-sm focus:outline-none focus:border-zinc-500 dark:focus:border-zinc-400"
                />
              </div>
            )}

            {mode === 'forgot' && generatedToken && (
              <>
                <div>
                  <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-300 mb-1.5">
                    Recovery Token
                  </label>
                  <input
                    type="text"
                    required
                    value={resetToken}
                    onChange={(e) => setResetToken(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-xs font-mono focus:outline-none focus:border-zinc-500 dark:focus:border-zinc-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-300 mb-1.5">
                    New Password
                  </label>
                  <input
                    type="password"
                    required
                    minLength={8}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Minimum 8 characters"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-sm focus:outline-none focus:border-zinc-500 dark:focus:border-zinc-400"
                  />
                </div>
              </>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 disabled:opacity-60 text-white dark:text-zinc-950 font-medium text-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              <span>
                {mode === 'login'
                  ? 'Sign In'
                  : mode === 'register'
                  ? 'Create Account'
                  : generatedToken
                  ? 'Update Password'
                  : 'Generate Reset Token'}
              </span>
            </button>
          </form>

          <div className="mt-6 pt-5 border-t border-zinc-200 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-2 text-xs text-zinc-500 dark:text-zinc-400">
            {mode === 'login' ? (
              <button
                type="button"
                onClick={() => {
                  setError('');
                  setMode('forgot');
                }}
                className="inline-flex items-center gap-1 hover:text-zinc-900 dark:hover:text-white cursor-pointer"
              >
                <KeyRound className="w-3.5 h-3.5" />
                <span>Forgot password</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setError('');
                  setMode('login');
                }}
                className="hover:text-zinc-900 dark:hover:text-white cursor-pointer"
              >
                Back to Sign In
              </button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
