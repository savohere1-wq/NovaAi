import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  BookOpen,
  Check,
  Copy,
  Download,
  Edit3,
  ExternalLink,
  Globe,
  Loader2,
  Mic,
  MicOff,
  Paperclip,
  Pause,
  Phone,
  Play,
  RefreshCw,
  Send,
  SlidersHorizontal,
  Square,
  ThumbsDown,
  ThumbsUp,
  Volume2,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { apiFetch, apiStreamPost } from '../lib/api';
import { SUPPORTED_LANGUAGES, VOICE_PERSONAS } from '../lib/languages';
import { LiveVoiceCall } from '../components/voice/LiveVoiceCall';
import { MarkdownRenderer } from '../components/ui/MarkdownRenderer';
import type {
  AttachmentPayload,
  ChatMessage,
  CitationSource,
  LanguagePreference,
  ThinkingMode,
} from '../types/nova';

interface ChatPageProps {
  conversationId: string | null;
  newChatKey?: number;
  onConversationCreated: (id: string) => void;
  onConversationUpdated: () => void;
  onOpenCodeInWorkspace: (code: string, language: string) => void;
  navigate: (path: string) => void;
}

const SUGGESTED_PROMPTS = [
  {
    title: 'Explain a concept simply',
    prompt: 'Explain how HTTPS encryption and TLS handshakes work in simple terms with a quick diagram.',
  },
  {
    title: 'Learn any language',
    prompt: 'Teach me 5 useful everyday phrases in Japanese with pronunciation and let us practice a mini dialogue!',
    lang: 'ja' as LanguagePreference,
    learn: true,
  },
  {
    title: 'Live web research',
    prompt: 'Summarize the latest major developments in renewable grid battery storage and cite verified sources.',
    research: true,
  },
  {
    title: 'Hindi / Hinglish help',
    prompt: 'Mujhe SQL joins (INNER, LEFT, RIGHT) simple Hinglish mein example ke saath samjhao.',
    lang: 'hinglish' as LanguagePreference,
  },
];

export function ChatPage({
  conversationId,
  newChatKey = 0,
  onConversationCreated,
  onConversationUpdated,
  onOpenCodeInWorkspace,
}: ChatPageProps) {
  const { user, models, preferences, updatePreferences, notify } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [input, setInput] = useState('');
  const [selectedModel, setSelectedModel] = useState(preferences.defaultModel || 'gemini-3.1-flash-lite');
  const [language, setLanguage] = useState<LanguagePreference>(preferences.language || 'auto');
  const [learningMode, setLearningMode] = useState(false);
  const [thinkingMode, setThinkingMode] = useState<ThinkingMode>(preferences.thinkingMode || 'low');
  const [researchMode, setResearchMode] = useState(false);
  const [optionsOpen, setOptionsOpen] = useState(false);
  const [liveCallOpen, setLiveCallOpen] = useState(false);
  const [attachments, setAttachments] = useState<AttachmentPayload[]>([]);
  const [uploadingFile, setUploadingFile] = useState(false);

  const [streaming, setStreaming] = useState(false);
  const [streamNotice, setStreamNotice] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Voice recording & TTS playback
  const [recording, setRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [voiceAutoSpeak, setVoiceAutoSpeak] = useState(false);
  const [playingMessageId, setPlayingMessageId] = useState<string | null>(null);
  const [audioPaused, setAudioPaused] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const abortRef = useRef<AbortController | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const skipNextLoadConvIdRef = useRef<string | null>(null);
  const streamingRef = useRef(false);

  const activeModelObj = models.find((m) => m.id === selectedModel) || models[0];

  useEffect(() => {
    if (models.length > 0 && !models.some((m) => m.id === selectedModel)) {
      setSelectedModel(models[0].id);
    }
  }, [models, selectedModel]);

  useEffect(() => {
    if (!conversationId) {
      if (!streamingRef.current) {
        setMessages([]);
      }
      return;
    }
    if (skipNextLoadConvIdRef.current === conversationId) {
      skipNextLoadConvIdRef.current = null;
      return;
    }
    if (!user) return;
    let cancelled = false;
    setLoadingMessages(true);
    apiFetch<{ messages: ChatMessage[] }>(`/api/conversations/${conversationId}/messages`)
      .then((data) => {
        if (!cancelled) {
          setMessages(data.messages || []);
        }
      })
      .catch((err) => {
        if (!cancelled) notify(err instanceof Error ? err.message : 'Failed to load messages', 'error');
      })
      .finally(() => {
        if (!cancelled) setLoadingMessages(false);
      });
    return () => {
      cancelled = true;
    };
  }, [conversationId, user, notify]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, streaming]);

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    setPlayingMessageId(null);
    setAudioPaused(false);
  };

  const handlePlayTts = async (messageId: string, text: string) => {
    if (playingMessageId === messageId && audioRef.current) {
      if (audioRef.current.paused) {
        await audioRef.current.play();
        setAudioPaused(false);
      } else {
        audioRef.current.pause();
        setAudioPaused(true);
      }
      return;
    }

    stopAudio();
    try {
      setPlayingMessageId(messageId);
      const res = await apiFetch<{ audioBase64: string; mimeType: string }>('/api/voice/tts', {
        method: 'POST',
        body: JSON.stringify({ text: text.replace(/[#*`]/g, ''), voiceName: preferences.voiceName || 'Kore' }),
      });
      const audio = new Audio(`data:${res.mimeType};base64,${res.audioBase64}`);
      audioRef.current = audio;
      audio.onended = () => {
        setPlayingMessageId(null);
        setAudioPaused(false);
      };
      await audio.play();
    } catch (err) {
      setPlayingMessageId(null);
      notify(err instanceof Error ? err.message : 'Speech playback failed', 'error');
    }
  };

  const toggleMicrophone = async () => {
    if (recording && mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setRecording(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(audioChunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        if (blob.size < 400) return;
        setTranscribing(true);
        try {
          const fd = new FormData();
          fd.append('audio', blob, 'recording.webm');
          const res = await apiFetch<{ text: string }>('/api/voice/transcribe', {
            method: 'POST',
            body: fd,
          });
          if (res.text) {
            setInput((prev) => (prev ? `${prev} ${res.text}` : res.text));
          }
        } catch (err) {
          notify(err instanceof Error ? err.message : 'Transcription failed', 'error');
        } finally {
          setTranscribing(false);
        }
      };
      mediaRecorderRef.current = recorder;
      recorder.start();
      setRecording(true);
    } catch {
      notify('Microphone permission denied or unavailable.', 'error');
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';
    setUploadingFile(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const data = await apiFetch<{ attachment: AttachmentPayload }>('/api/chat/extract-attachment', {
        method: 'POST',
        body: fd,
      });
      setAttachments((prev) => [...prev, data.attachment]);
      notify(`Attached ${file.name}`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to attach file', 'error');
    } finally {
      setUploadingFile(false);
    }
  };

  const sendMessage = async (opts?: {
    overrideText?: string;
    overrideResearch?: boolean;
    overrideLang?: LanguagePreference;
    overrideLearn?: boolean;
    editMessageId?: string;
    regenerateFromAssistantId?: string;
  }) => {
    if (streaming || !user) return;

    const textToSend = (opts?.overrideText ?? input).trim();
    const isRegen = Boolean(opts?.regenerateFromAssistantId);
    if (!isRegen && !textToSend && attachments.length === 0) return;

    setStreamNotice('');
    const currentAttachments = isRegen ? [] : [...attachments];
    if (!opts?.overrideText && !opts?.editMessageId && !isRegen) {
      setInput('');
      setAttachments([]);
    }

    const tempAssistantId = `temp-ai-${Date.now()}`;
    const tempUserId = `temp-u-${Date.now()}`;
    const effectiveResearch = opts?.overrideResearch ?? researchMode;
    const effectiveLang = opts?.overrideLang ?? language;
    const effectiveLearn = opts?.overrideLearn ?? learningMode;

    let nextMessagesSnapshot: ChatMessage[] = [];

    if (opts?.editMessageId) {
      const idx = messages.findIndex((m) => m.id === opts.editMessageId);
      const kept = idx >= 0 ? messages.slice(0, idx) : messages;
      nextMessagesSnapshot = [
        ...kept,
        {
          id: tempUserId,
          conversationId: conversationId || '',
          role: 'user',
          content: textToSend,
          createdAt: new Date().toISOString(),
        },
        {
          id: tempAssistantId,
          conversationId: conversationId || '',
          role: 'assistant',
          content: '',
          modelId: selectedModel,
          createdAt: new Date().toISOString(),
        },
      ];
    } else if (opts?.regenerateFromAssistantId) {
      const idx = messages.findIndex((m) => m.id === opts.regenerateFromAssistantId);
      const kept = idx >= 0 ? messages.slice(0, idx) : messages;
      nextMessagesSnapshot = [
        ...kept,
        {
          id: tempAssistantId,
          conversationId: conversationId || '',
          role: 'assistant',
          content: '',
          modelId: selectedModel,
          createdAt: new Date().toISOString(),
        },
      ];
    } else {
      nextMessagesSnapshot = [
        ...messages,
        {
          id: tempUserId,
          conversationId: conversationId || '',
          role: 'user',
          content: textToSend,
          attachments: currentAttachments,
          createdAt: new Date().toISOString(),
        },
        {
          id: tempAssistantId,
          conversationId: conversationId || '',
          role: 'assistant',
          content: '',
          modelId: selectedModel,
          createdAt: new Date().toISOString(),
        },
      ];
    }

    setMessages(nextMessagesSnapshot);
    streamingRef.current = true;
    setStreaming(true);
    const controller = new AbortController();
    abortRef.current = controller;

    let finalAssistantText = '';
    let resolvedConvId = conversationId || '';
    let finalCitations: CitationSource[] = [];
    let hadError = false;

    try {
      await apiStreamPost(
        '/api/chat/stream',
        {
          conversationId: resolvedConvId || undefined,
          message: textToSend,
          modelId: selectedModel,
          language: effectiveLang,
          learningMode: effectiveLearn,
          thinkingMode,
          researchMode: effectiveResearch,
          attachments: currentAttachments,
          editMessageId: opts?.editMessageId,
          regenerateFromAssistantId: opts?.regenerateFromAssistantId,
        },
        (ev) => {
          if (ev.type === 'meta') {
            if (typeof ev.conversationId === 'string') {
              resolvedConvId = ev.conversationId;
              if (!conversationId) {
                skipNextLoadConvIdRef.current = ev.conversationId;
                onConversationCreated(ev.conversationId);
              }
            }
            if (typeof ev.userMessageId === 'string' && ev.userMessageId) {
              setMessages((prev) =>
                prev.map((m) => (m.id === tempUserId ? { ...m, id: ev.userMessageId as string } : m))
              );
            }
          } else if (ev.type === 'delta' && typeof ev.text === 'string') {
            finalAssistantText += ev.text;
            setMessages((prev) =>
              prev.map((m) => (m.id === tempAssistantId ? { ...m, content: finalAssistantText } : m))
            );
          } else if (ev.type === 'citations' && Array.isArray(ev.citations)) {
            finalCitations = ev.citations as CitationSource[];
            setMessages((prev) =>
              prev.map((m) =>
                m.id === tempAssistantId ? { ...m, citations: finalCitations } : m
              )
            );
          } else if (ev.type === 'notice' && typeof ev.message === 'string') {
            setStreamNotice(ev.message);
          } else if (ev.type === 'error' && typeof ev.message === 'string') {
            hadError = true;
            notify(ev.message, 'error');
            setMessages((prev) =>
              prev.map((m) =>
                m.id === tempAssistantId
                  ? { ...m, content: `Error: ${ev.message}` }
                  : m
              )
            );
          } else if (ev.type === 'done') {
            const finalId = (ev.assistantMessageId as string) || tempAssistantId;
            const finalModel = (ev.modelId as string) || selectedModel;

            setMessages((prev) =>
              prev.map((m) =>
                m.id === tempAssistantId
                  ? {
                      ...m,
                      id: finalId,
                      modelId: finalModel,
                      tokensUsed: ev.tokensUsed as number,
                      latencyMs: ev.latencyMs as number,
                      citations: finalCitations.length > 0 ? finalCitations : m.citations,
                    }
                  : m
              )
            );

            onConversationUpdated();
            if (voiceAutoSpeak && finalAssistantText.trim()) {
              void handlePlayTts(finalId, finalAssistantText);
            }
          }
        },
        controller.signal
      );
    } catch (err) {
      if ((err as Error).name !== 'AbortError') {
        hadError = true;
        const msg = err instanceof Error ? err.message : 'Streaming failed';
        notify(msg, 'error');
        setMessages((prev) =>
          prev.map((m) =>
            m.id === tempAssistantId && !m.content ? { ...m, content: `Error: ${msg}` } : m
          )
        );
      }
    } finally {
      if (!finalAssistantText.trim() && !hadError && !controller.signal.aborted) {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === tempAssistantId && !m.content
              ? { ...m, content: 'No response was received from the model. Please try sending again.' }
              : m
          )
        );
      }
      streamingRef.current = false;
      setStreaming(false);
      abortRef.current = null;
      if (resolvedConvId) onConversationUpdated();
    }
  };

  const handleStop = () => {
    abortRef.current?.abort();
    streamingRef.current = false;
    setStreaming(false);
  };

  const handleFeedback = async (messageId: string, rating: 'up' | 'down') => {
    if (messageId.startsWith('temp-')) return;
    try {
      await apiFetch(`/api/messages/${messageId}/feedback`, {
        method: 'POST',
        body: JSON.stringify({ rating }),
      });
      setMessages((prev) => prev.map((m) => (m.id === messageId ? { ...m, feedback: rating } : m)));
      notify('Feedback saved', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to save feedback', 'error');
    }
  };

  const handleExportChat = () => {
    if (messages.length === 0) return;
    const md = messages
      .map((m) => `### ${m.role === 'user' ? 'User' : `NOVA AI (${m.modelId || selectedModel})`}\n\n${m.content}`)
      .join('\n\n---\n\n');
    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nova-chat-${conversationId || 'export'}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Simple Top Bar */}
      <div className="h-14 px-4 sm:px-6 border-b border-zinc-200 dark:border-zinc-800/80 bg-white/85 dark:bg-[#0E0E11]/85 backdrop-blur-md flex items-center justify-between gap-3 shrink-0 relative z-20">
        <div className="flex items-center gap-2.5 min-w-0">
          <select
            value={selectedModel}
            onChange={(e) => setSelectedModel(e.target.value)}
            aria-label="Select AI Model"
            className="px-3 py-1.5 rounded-lg bg-zinc-100 dark:bg-[#141416] border border-zinc-200 dark:border-zinc-800 text-xs sm:text-sm font-medium text-zinc-900 dark:text-white focus:outline-none focus:border-zinc-500 cursor-pointer max-w-[210px] truncate"
          >
            {models.length === 0 ? (
              <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite (Fast)</option>
            ) : (
              models.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))
            )}
          </select>

          <button
            type="button"
            onClick={() => setResearchMode((r) => !r)}
            disabled={models.length > 0 && !activeModelObj?.capabilities.webSearch}
            title="Toggle Live Web Search"
            className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer whitespace-nowrap ${
              researchMode
                ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-950 border-zinc-900 dark:border-white'
                : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800/70'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Web Search</span>
          </button>
          <button
            type="button"
            onClick={() => setLearningMode((l) => !l)}
            title="Toggle All-Language Learning Tutor"
            className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer whitespace-nowrap ${
              learningMode
                ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-950 border-zinc-900 dark:border-white'
                : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800/70'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Language Tutor</span>
          </button>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setLiveCallOpen(true)}
            title="Start Live Voice Call"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-950 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap"
          >
            <Phone className="w-3.5 h-3.5" />
            <span>Live Call</span>
          </button>

          {/* Compact Animated Options Popover */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setOptionsOpen((o) => !o)}
              aria-label="Chat Options"
              aria-expanded={optionsOpen}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                optionsOpen
                  ? 'bg-zinc-200/80 dark:bg-zinc-800 border-zinc-300 dark:border-zinc-700 text-zinc-900 dark:text-white'
                  : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800/70'
              }`}
            >
              <motion.span
                animate={{ rotate: optionsOpen ? 90 : 0 }}
                transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
                className="inline-flex items-center"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
              </motion.span>
              <span className="hidden sm:inline">Options</span>
            </button>

            <AnimatePresence>
              {optionsOpen && (
                <motion.div
                  key="chat-options-popover"
                  initial={{ opacity: 0, y: -8, scale: 0.96 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -8, scale: 0.96 }}
                  transition={{ duration: 0.18, ease: [0.22, 1, 0.36, 1] }}
                  className="absolute right-0 mt-2 w-72 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-4 shadow-xl space-y-3.5 z-30 origin-top-right"
                >
                  <div>
                    <label className="block text-[11px] font-medium text-zinc-500 mb-1">Language (All Languages)</label>
                    <select
                      value={language}
                      onChange={(e) => {
                        const next = e.target.value;
                        setLanguage(next);
                        void updatePreferences({ language: next });
                      }}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-xs text-zinc-900 dark:text-white"
                    >
                      {SUPPORTED_LANGUAGES.map((l) => (
                        <option key={l.code} value={l.code}>
                          {l.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-zinc-500 mb-1">Voice Persona</label>
                    <select
                      value={preferences.voiceName || 'Zephyr'}
                      onChange={(e) => void updatePreferences({ voiceName: e.target.value })}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-xs text-zinc-900 dark:text-white"
                    >
                      {VOICE_PERSONAS.map((v) => (
                        <option key={v.id} value={v.id}>
                          {v.name} — {v.tagline}
                        </option>
                      ))}
                    </select>
                  </div>

                  {activeModelObj?.capabilities.thinking && (
                    <div>
                      <label className="block text-[11px] font-medium text-zinc-500 mb-1">Thinking Depth</label>
                      <select
                        value={thinkingMode}
                        onChange={(e) => setThinkingMode(e.target.value as ThinkingMode)}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-xs text-zinc-900 dark:text-white"
                      >
                        <option value="low">Fast</option>
                        <option value="medium">Balanced</option>
                        <option value="high">Deep Reasoning</option>
                      </select>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-xs text-zinc-700 dark:text-zinc-300">Auto-speak replies</span>
                    <button
                      type="button"
                      onClick={() => setVoiceAutoSpeak((v) => !v)}
                      className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                        voiceAutoSpeak
                          ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-950'
                          : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400'
                      }`}
                    >
                      {voiceAutoSpeak ? 'On' : 'Off'}
                    </button>
                  </div>

                  {messages.length > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        handleExportChat();
                        setOptionsOpen(false);
                      }}
                      className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-lg border border-zinc-200 dark:border-zinc-800 text-xs font-medium hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export Markdown</span>
                    </button>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {streamNotice && (
        <div className="px-6 py-2 bg-zinc-100 dark:bg-[#141416] border-b border-zinc-200 dark:border-zinc-800 text-xs text-zinc-600 dark:text-zinc-300 flex items-center justify-between">
          <span>{streamNotice}</span>
          <button type="button" onClick={() => setStreamNotice('')} className="cursor-pointer">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Message Thread */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-6" onClick={() => optionsOpen && setOptionsOpen(false)}>
        {loadingMessages ? (
          <div className="max-w-3xl mx-auto space-y-4">
            <div className="h-16 rounded-2xl bg-zinc-200/70 dark:bg-zinc-800/50 animate-pulse" />
            <div className="h-32 rounded-2xl bg-zinc-200/70 dark:bg-zinc-800/50 animate-pulse" />
          </div>
        ) : messages.length === 0 ? (
          <AnimatePresence mode="wait">
            <motion.div
              key={`new-chat-hero-${newChatKey}`}
              initial={{ opacity: 0, y: 18, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.98 }}
              transition={{ duration: 0.34, ease: [0.22, 1, 0.36, 1] }}
              className="max-w-2xl mx-auto h-full flex flex-col justify-center py-8"
            >
              <div className="text-center mb-8">
                <motion.img
                  src="/src/assets/images/avatar_nova_default_1794634324180.jpg"
                  alt="NOVA AI"
                  referrerPolicy="no-referrer"
                  initial={{ opacity: 0, scale: 0.8, rotate: -6 }}
                  animate={{ opacity: 1, scale: 1, rotate: 0 }}
                  transition={{ duration: 0.36, delay: 0.04, ease: [0.22, 1, 0.36, 1] }}
                  className="w-11 h-11 rounded-2xl mx-auto mb-4 object-cover border border-zinc-200 dark:border-zinc-800 shadow-sm"
                />
                <motion.h1
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.28, delay: 0.08 }}
                  className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-zinc-900 dark:text-white"
                >
                  How can I help?
                </motion.h1>
                <motion.p
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.28, delay: 0.12 }}
                  className="mt-2 text-sm text-zinc-500 dark:text-zinc-400"
                >
                  Ask anything, attach files, or search the live web.
                </motion.p>
              </div>

              <div className="grid sm:grid-cols-2 gap-3">
                {SUGGESTED_PROMPTS.map((item, idx) => (
                  <motion.button
                    key={item.title}
                    type="button"
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    whileHover={{ y: -2 }}
                    whileTap={{ scale: 0.99 }}
                    transition={{ duration: 0.26, delay: 0.14 + idx * 0.05, ease: [0.22, 1, 0.36, 1] }}
                    onClick={() => {
                      if (item.research) setResearchMode(true);
                      if (item.lang) setLanguage(item.lang);
                      if (item.learn) setLearningMode(true);
                      void sendMessage({
                        overrideText: item.prompt,
                        overrideResearch: item.research,
                        overrideLang: item.lang,
                        overrideLearn: item.learn,
                      });
                    }}
                    className="text-left p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] hover:border-zinc-400 dark:hover:border-zinc-600 transition-colors cursor-pointer"
                  >
                    <div className="text-xs font-semibold text-zinc-900 dark:text-white mb-1">{item.title}</div>
                    <div className="text-xs text-zinc-500 dark:text-zinc-400 line-clamp-2 leading-relaxed">
                      {item.prompt}
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          </AnimatePresence>
        ) : (
          <div className="max-w-3xl mx-auto space-y-5">
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
                className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
              >
                {msg.role === 'user' ? (
                  <div className="max-w-[82%] rounded-3xl px-4 py-2.5 bg-zinc-200/80 dark:bg-[#232327] text-zinc-900 dark:text-zinc-50">
                    {editingId === msg.id ? (
                      <div className="space-y-2 min-w-[260px]">
                        <textarea
                          value={editDraft}
                          onChange={(e) => setEditDraft(e.target.value)}
                          rows={3}
                          className="w-full p-2 rounded-lg bg-white dark:bg-[#09090B] border border-zinc-300 dark:border-zinc-700 text-sm focus:outline-none"
                        />
                        <div className="flex justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setEditingId(null)}
                            className="px-3 py-1 rounded-lg text-xs border border-zinc-300 dark:border-zinc-700 cursor-pointer"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const draft = editDraft;
                              setEditingId(null);
                              void sendMessage({ overrideText: draft, editMessageId: msg.id });
                            }}
                            className="px-3 py-1 rounded-lg text-xs bg-zinc-900 dark:bg-white text-white dark:text-zinc-950 font-medium cursor-pointer"
                          >
                            Save & Send
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        {msg.attachments && msg.attachments.length > 0 && (
                          <div className="mb-2 flex flex-wrap gap-2">
                            {msg.attachments.map((att, idx) =>
                              att.base64 && att.mimeType.startsWith('image/') ? (
                                <img
                                  key={idx}
                                  src={`data:${att.mimeType};base64,${att.base64}`}
                                  alt={att.name}
                                  referrerPolicy="no-referrer"
                                  className="max-h-44 rounded-xl border border-zinc-700 object-cover"
                                />
                              ) : (
                                <span key={idx} className="text-xs font-mono text-zinc-500 dark:text-zinc-300">
                                  Attachment: {att.name}
                                </span>
                              )
                            )}
                          </div>
                        )}
                        <div className="text-sm whitespace-pre-wrap leading-relaxed">{msg.content}</div>
                        <div className="mt-1 flex items-center justify-end gap-2 text-[11px] text-zinc-500">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingId(msg.id);
                              setEditDraft(msg.content);
                            }}
                            className="hover:text-zinc-900 dark:hover:text-white inline-flex items-center gap-1 cursor-pointer"
                          >
                            <Edit3 className="w-3 h-3" />
                            <span>Edit</span>
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                ) : (
                  /* ChatGPT-style unboxed open flow for assistant answers */
                  <div className="w-full py-1">
                    <div className="flex items-center gap-2.5 mb-2 text-xs text-zinc-500 dark:text-zinc-400">
                      <img
                        src="/src/assets/images/avatar_nova_default_1794634324180.jpg"
                        alt="NOVA AI"
                        referrerPolicy="no-referrer"
                        className="w-6 h-6 rounded-full object-cover border border-zinc-200 dark:border-zinc-700 shrink-0"
                      />
                      <span className="font-semibold text-zinc-900 dark:text-zinc-100">NOVA AI</span>
                      <span aria-hidden="true">·</span>
                      <span>{msg.modelId || selectedModel}</span>
                      {msg.latencyMs ? (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono tabular-nums">{(msg.latencyMs / 1000).toFixed(2)}s</span>
                        </>
                      ) : null}
                    </div>

                    <div className="sm:pl-8.5">
                      {msg.content ? (
                        <MarkdownRenderer content={msg.content} onOpenInWorkspace={onOpenCodeInWorkspace} />
                      ) : (
                        <div className="flex items-center gap-2 text-sm text-zinc-400 py-1.5">
                          <Loader2 className="w-4 h-4 animate-spin text-zinc-400" />
                          <span>Thinking...</span>
                        </div>
                      )}

                      {/* Verified Web Citations */}
                      {msg.citations && msg.citations.length > 0 && (
                        <div className="mt-4">
                          <div className="text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-2">
                            Sources ({msg.citations.length})
                          </div>
                          <div className="grid sm:grid-cols-2 gap-2">
                            {msg.citations.map((c, idx) => (
                              <a
                                key={idx}
                                href={c.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-zinc-100/70 dark:bg-[#141416] border border-zinc-200 dark:border-zinc-800 hover:border-zinc-400 dark:hover:border-zinc-600 text-xs transition-colors"
                              >
                                <div className="min-w-0">
                                  <div className="font-medium text-zinc-900 dark:text-white truncate">{c.title}</div>
                                  <div className="text-[11px] text-zinc-500 truncate">{c.domain}</div>
                                </div>
                                <ExternalLink className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                              </a>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Compact Open Action Row */}
                      {msg.content && !streaming && (
                        <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 text-xs text-zinc-500 dark:text-zinc-400">
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={async () => {
                                await navigator.clipboard.writeText(msg.content);
                                setCopiedId(msg.id);
                                setTimeout(() => setCopiedId(null), 1600);
                              }}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-zinc-200/60 dark:hover:bg-zinc-800/80 cursor-pointer"
                            >
                              {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                              <span>{copiedId === msg.id ? 'Copied' : 'Copy'}</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => handlePlayTts(msg.id, msg.content)}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-zinc-200/60 dark:hover:bg-zinc-800/80 cursor-pointer"
                            >
                              {playingMessageId === msg.id ? (
                                audioPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />
                              ) : (
                                <Volume2 className="w-3.5 h-3.5" />
                              )}
                              <span>{playingMessageId === msg.id ? (audioPaused ? 'Resume' : 'Pause') : 'Listen'}</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => void sendMessage({ regenerateFromAssistantId: msg.id })}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-zinc-200/60 dark:hover:bg-zinc-800/80 cursor-pointer"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                              <span>Regenerate</span>
                            </button>
                          </div>

                          {user && (
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => handleFeedback(msg.id, 'up')}
                                aria-label="Helpful"
                                className={`p-1.5 rounded-lg hover:bg-zinc-200/60 dark:hover:bg-zinc-800/80 cursor-pointer ${
                                  msg.feedback === 'up' ? 'text-emerald-500' : ''
                                }`}
                              >
                                <ThumbsUp className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleFeedback(msg.id, 'down')}
                                aria-label="Not helpful"
                                className={`p-1.5 rounded-lg hover:bg-zinc-200/60 dark:hover:bg-zinc-800/80 cursor-pointer ${
                                  msg.feedback === 'down' ? 'text-red-500' : ''
                                }`}
                              >
                                <ThumbsDown className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
            <div ref={bottomRef} />
          </div>
        )}
      </div>

      {/* Composer */}
      <div className="p-4 sm:px-6 border-t border-zinc-200 dark:border-zinc-800/80 bg-white/85 dark:bg-[#0E0E11]/90 backdrop-blur-md shrink-0">
        <div className="max-w-3xl mx-auto">
          {attachments.length > 0 && (
            <div className="mb-2.5 flex flex-wrap gap-2">
              {attachments.map((att, idx) => (
                <div
                  key={idx}
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-100 dark:bg-[#141416] border border-zinc-200 dark:border-zinc-800 text-xs"
                >
                  <span className="truncate max-w-[180px]">{att.name}</span>
                  <button
                    type="button"
                    onClick={() => setAttachments((prev) => prev.filter((_, i) => i !== idx))}
                    className="text-zinc-400 hover:text-red-400 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-3 focus-within:border-zinc-500 dark:focus-within:border-zinc-600 transition-colors">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  void sendMessage();
                }
              }}
              rows={2}
              placeholder="Ask NOVA AI anything..."
              className="w-full resize-none bg-transparent text-sm text-zinc-900 dark:text-white placeholder:text-zinc-400 focus:outline-none"
            />

            <div className="mt-2 pt-2 border-t border-zinc-100 dark:border-zinc-800/80 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,.pdf,.docx,.txt,.md,.csv,.xlsx,.ts,.tsx,.js,.py,.json"
                  onChange={handleFileSelect}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadingFile}
                  title="Attach image or document"
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
                >
                  {uploadingFile ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Paperclip className="w-3.5 h-3.5" />}
                  <span>Attach</span>
                </button>

                <button
                  type="button"
                  onClick={toggleMicrophone}
                  disabled={transcribing}
                  title="Voice dictation"
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                    recording
                      ? 'bg-red-500/15 text-red-500 border border-red-500/40'
                      : 'text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                  }`}
                >
                  {transcribing ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : recording ? (
                    <MicOff className="w-3.5 h-3.5" />
                  ) : (
                    <Mic className="w-3.5 h-3.5" />
                  )}
                  <span>{recording ? 'Stop Mic' : transcribing ? 'Transcribing' : 'Voice'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setLiveCallOpen(true)}
                  title="Open Live Voice Call"
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors cursor-pointer"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Live Call</span>
                </button>
              </div>

              {streaming ? (
                <button
                  type="button"
                  onClick={handleStop}
                  className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-medium cursor-pointer"
                >
                  <Square className="w-3 h-3 fill-current" />
                  <span>Stop</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => void sendMessage()}
                  disabled={!input.trim() && attachments.length === 0}
                  className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 disabled:opacity-35 text-white dark:text-zinc-950 text-xs font-medium transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Live Voice Call Modal Overlay */}
      <AnimatePresence>
        {liveCallOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 12 }}
              transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
              className="w-full max-w-2xl"
            >
              <LiveVoiceCall
                initialLanguage={language}
                initialLearningMode={learningMode}
                onClose={() => setLiveCallOpen(false)}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
