import React, { useEffect, useState } from 'react';
import { Code2, Download, Eye, FilePlus, Loader2, Play, Plus, Save, Trash2 } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { MarkdownRenderer } from '../components/ui/MarkdownRenderer';
import type { CodingFile, CodingProject } from '../types/nova';

interface CodingWorkspacePageProps {
  pendingSnippet: { code: string; language: string } | null;
  onClearPendingSnippet: () => void;
}

export function CodingWorkspacePage({ pendingSnippet, onClearPendingSnippet }: CodingWorkspacePageProps) {
  const { notify } = useAuth();
  const [projects, setProjects] = useState<CodingProject[]>([]);
  const [activeProject, setActiveProject] = useState<CodingProject | null>(null);
  const [activeFileIdx, setActiveFileIdx] = useState(0);
  const [newFileName, setNewFileName] = useState('');
  const [showPreview, setShowPreview] = useState(true);

  const [aiAction, setAiAction] = useState<'generate' | 'explain' | 'debug' | 'optimize'>('generate');
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiRunning, setAiRunning] = useState(false);
  const [aiResponse, setAiResponse] = useState('');
  const [saving, setSaving] = useState(false);

  const loadProjects = async () => {
    try {
      const res = await apiFetch<{ projects: CodingProject[] }>('/api/workspace/projects');
      if (res.projects.length > 0) {
        setProjects(res.projects);
        setActiveProject(res.projects[0]);
      } else {
        const created = await apiFetch<{ project: CodingProject }>('/api/workspace/projects', {
          method: 'POST',
          body: JSON.stringify({ name: 'Starter Web Sandbox', description: 'Sandboxed HTML/CSS/JS workspace' }),
        });
        setProjects([created.project]);
        setActiveProject(created.project);
      }
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to load workspace', 'error');
    }
  };

  useEffect(() => {
    void loadProjects();
  }, []);

  useEffect(() => {
    if (pendingSnippet && activeProject) {
      const ext = pendingSnippet.language === 'html' ? 'html' : pendingSnippet.language === 'python' ? 'py' : pendingSnippet.language || 'txt';
      const newFile: CodingFile = {
        path: `imported-${Date.now().toString().slice(-4)}.${ext}`,
        language: pendingSnippet.language || 'text',
        content: pendingSnippet.code,
      };
      const updated: CodingProject = {
        ...activeProject,
        files: [...activeProject.files, newFile],
      };
      setActiveProject(updated);
      setActiveFileIdx(updated.files.length - 1);
      onClearPendingSnippet();
      notify(`Imported ${newFile.path} into Coding Studio`, 'success');
    }
  }, [pendingSnippet, activeProject]);

  const activeFile = activeProject?.files[activeFileIdx] || null;

  const updateActiveFileContent = (content: string) => {
    if (!activeProject || !activeFile) return;
    const files = activeProject.files.map((f, idx) => (idx === activeFileIdx ? { ...f, content } : f));
    setActiveProject({ ...activeProject, files });
  };

  const handleSaveProject = async () => {
    if (!activeProject) return;
    setSaving(true);
    try {
      await apiFetch(`/api/workspace/projects/${activeProject.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ name: activeProject.name, files: activeProject.files }),
      });
      setProjects((prev) => prev.map((p) => (p.id === activeProject.id ? activeProject : p)));
      notify('Project saved', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Save failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleNewProject = async () => {
    try {
      const created = await apiFetch<{ project: CodingProject }>('/api/workspace/projects', {
        method: 'POST',
        body: JSON.stringify({ name: `Project ${projects.length + 1}` }),
      });
      setProjects((prev) => [created.project, ...prev]);
      setActiveProject(created.project);
      setActiveFileIdx(0);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to create project', 'error');
    }
  };

  const handleAddFile = () => {
    if (!activeProject || !newFileName.trim()) return;
    const clean = newFileName.trim();
    const ext = clean.split('.').pop()?.toLowerCase() || 'txt';
    const langMap: Record<string, string> = {
      html: 'html',
      css: 'css',
      js: 'javascript',
      ts: 'typescript',
      tsx: 'typescript',
      py: 'python',
      json: 'json',
      sql: 'sql',
    };
    const nextFile: CodingFile = { path: clean, language: langMap[ext] || ext, content: '' };
    const updated = { ...activeProject, files: [...activeProject.files, nextFile] };
    setActiveProject(updated);
    setActiveFileIdx(updated.files.length - 1);
    setNewFileName('');
  };

  const handleDownloadFile = () => {
    if (!activeFile) return;
    const blob = new Blob([activeFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeFile.path;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleAiAssist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeFile) return;
    setAiRunning(true);
    try {
      const res = await apiFetch<{ output: string }>('/api/workspace/assist', {
        method: 'POST',
        body: JSON.stringify({
          action: aiAction,
          language: activeFile.language,
          code: activeFile.content,
          instruction: aiPrompt,
        }),
      });
      setAiResponse(res.output);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'AI assist failed', 'error');
    } finally {
      setAiRunning(false);
    }
  };

  const htmlPreviewDoc = (() => {
    if (!activeProject) return '';
    const htmlFile =
      activeFile?.language === 'html'
        ? activeFile
        : activeProject.files.find((f) => f.language === 'html' || f.path.endsWith('.html'));
    if (htmlFile) return htmlFile.content;
    return `<html><body style="font-family:monospace;padding:24px;background:#09090B;color:#a1a1aa;">Preview is active for HTML files. Select or create an .html file to render inside the sandboxed browser iframe.</body></html>`;
  })();

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="px-4 sm:px-6 h-14 border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#0E0E11] flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <Code2 className="w-4 h-4 text-zinc-700 dark:text-zinc-200 shrink-0" />
          <select
            value={activeProject?.id || ''}
            onChange={(e) => {
              const found = projects.find((p) => p.id === e.target.value);
              if (found) {
                setActiveProject(found);
                setActiveFileIdx(0);
              }
            }}
            className="px-3 py-1.5 rounded-lg bg-zinc-100 dark:bg-[#141416] border border-zinc-200 dark:border-zinc-800 text-xs sm:text-sm font-medium truncate max-w-[200px]"
          >
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={handleNewProject}
            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 text-xs hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">New Project</span>
          </button>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setShowPreview((s) => !s)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border cursor-pointer ${
              showPreview
                ? 'bg-zinc-200 dark:bg-zinc-800 border-zinc-400 dark:border-zinc-600 text-zinc-900 dark:text-white'
                : 'border-zinc-200 dark:border-zinc-800'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Sandbox Preview</span>
          </button>
          <button
            type="button"
            onClick={handleDownloadFile}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 text-xs cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Download</span>
          </button>
          <button
            type="button"
            onClick={handleSaveProject}
            disabled={saving}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-950 text-xs font-medium cursor-pointer"
          >
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
            <span>Save</span>
          </button>
        </div>
      </div>

      {/* Main Split Grid */}
      <div className="flex-1 min-h-0 grid lg:grid-cols-12">
        {/* File Explorer */}
        <div className="lg:col-span-2 border-r border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-[#0E0E11] p-3 flex flex-col gap-3 overflow-y-auto">
          <div className="text-xs font-semibold text-zinc-500 dark:text-zinc-400">Files</div>
          <div className="space-y-1">
            {activeProject?.files.map((f, idx) => (
              <div
                key={f.path + idx}
                onClick={() => setActiveFileIdx(idx)}
                className={`group flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-mono cursor-pointer ${
                  idx === activeFileIdx
                    ? 'bg-zinc-200 dark:bg-zinc-800 text-zinc-950 dark:text-white'
                    : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200/60 dark:hover:bg-zinc-800/50'
                }`}
              >
                <span className="truncate">{f.path}</span>
                {activeProject.files.length > 1 && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      const next = activeProject.files.filter((_, i) => i !== idx);
                      setActiveProject({ ...activeProject, files: next });
                      setActiveFileIdx(0);
                    }}
                    className="opacity-0 group-hover:opacity-100 hover:text-red-400 cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-zinc-200 dark:border-zinc-800 flex gap-1.5">
            <input
              type="text"
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              placeholder="app.ts"
              className="flex-1 min-w-0 px-2 py-1 rounded-md bg-white dark:bg-[#141416] border border-zinc-200 dark:border-zinc-800 text-xs font-mono"
            />
            <button
              type="button"
              onClick={handleAddFile}
              title="Add file"
              className="p-1.5 rounded-md bg-zinc-900 dark:bg-white text-white dark:text-zinc-950 cursor-pointer"
            >
              <FilePlus className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Code Editor */}
        <div className={`${showPreview ? 'lg:col-span-5' : 'lg:col-span-6'} flex flex-col min-h-[300px] border-r border-zinc-200 dark:border-zinc-800 bg-[#0D0D0F]`}>
          <div className="px-4 py-2 border-b border-zinc-800 text-xs font-mono text-zinc-400 flex justify-between">
            <span>{activeFile?.path || 'No file selected'}</span>
            <span>{activeFile?.language}</span>
          </div>
          <textarea
            value={activeFile?.content || ''}
            onChange={(e) => updateActiveFileContent(e.target.value)}
            spellCheck={false}
            className="flex-1 w-full p-4 bg-transparent text-zinc-100 font-mono text-[13px] leading-relaxed resize-none focus:outline-none"
          />
        </div>

        {/* Sandboxed Browser Preview + AI Assistant */}
        <div className={`${showPreview ? 'lg:col-span-5' : 'lg:col-span-4'} flex flex-col min-h-0 bg-white dark:bg-[#09090B]`}>
          {showPreview && (
            <div className="h-1/2 min-h-[220px] border-b border-zinc-200 dark:border-zinc-800 flex flex-col">
              <div className="px-3 py-1.5 bg-zinc-100 dark:bg-[#141416] text-[11px] font-mono text-zinc-500 dark:text-zinc-400 border-b border-zinc-200 dark:border-zinc-800">
                Isolated Browser Sandbox (scripts isolated, zero server execution)
              </div>
              <iframe
                title="NOVA Sandboxed Preview"
                sandbox="allow-scripts"
                srcDoc={htmlPreviewDoc}
                className="flex-1 w-full bg-white"
              />
            </div>
          )}

          <div className="flex-1 min-h-0 flex flex-col p-4 overflow-y-auto space-y-3">
            <form onSubmit={handleAiAssist} className="space-y-2.5 shrink-0">
              <div className="flex items-center gap-2">
                {(['generate', 'explain', 'debug', 'optimize'] as const).map((act) => (
                  <button
                    key={act}
                    type="button"
                    onClick={() => setAiAction(act)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium capitalize cursor-pointer ${
                      aiAction === act
                        ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-950'
                        : 'bg-zinc-100 dark:bg-[#141416] text-zinc-600 dark:text-zinc-300'
                    }`}
                  >
                    {act}
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder={`Ask NOVA to ${aiAction} ${activeFile?.path || 'code'}...`}
                  className="flex-1 px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#141416] border border-zinc-200 dark:border-zinc-800 text-xs focus:outline-none focus:border-zinc-500"
                />
                <button
                  type="submit"
                  disabled={aiRunning}
                  className="px-3.5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-950 text-xs font-medium flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  {aiRunning ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                  <span>Run</span>
                </button>
              </div>
            </form>

            {aiResponse && (
              <div className="p-4 rounded-xl bg-zinc-50 dark:bg-[#141416] border border-zinc-200 dark:border-zinc-800 text-xs">
                <MarkdownRenderer
                  content={aiResponse}
                  onOpenInWorkspace={(code) => {
                    updateActiveFileContent(code);
                    notify('Applied code snippet to active file', 'success');
                  }}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
