import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import type { UsageSummary } from '../types/nova';

interface DashboardPageProps {
  navigate: (path: string) => void;
}

export function DashboardPage({ navigate }: DashboardPageProps) {
  const { user, notify } = useAuth();
  const [summary, setSummary] = useState<UsageSummary | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch<{ summary: UsageSummary }>('/api/dashboard/summary')
      .then((res) => setSummary(res.summary))
      .catch((err) => notify(err instanceof Error ? err.message : 'Failed to load dashboard', 'error'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="p-10 flex items-center justify-center text-slate-500">
        <Loader2 className="w-5 h-5 animate-spin mr-2" />
        <span>Loading usage analytics...</span>
      </div>
    );
  }

  if (!summary) return null;

  const msgPct = Math.min(100, Math.round((summary.dailyQuotaUsed / Math.max(1, summary.dailyQuotaLimit)) * 100));
  const imgPct = Math.min(100, Math.round((summary.imageQuotaUsed / Math.max(1, summary.imageQuotaLimit)) * 100));

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Workspace Overview</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {user?.name} · {user?.email} · {user?.plan.toUpperCase()} Plan
          </p>
        </div>
        <button
          type="button"
          onClick={() => navigate('/subscription')}
          className="px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-medium hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer w-fit"
        >
          Manage Subscription
        </button>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Conversations', value: summary.totalConversations.toLocaleString(), sub: `${summary.totalMessages.toLocaleString()} messages` },
          { label: 'Total Tokens', value: summary.totalTokens.toLocaleString(), sub: `${summary.avgLatencyMs} ms avg latency` },
          { label: 'Studio Visuals', value: summary.totalImages.toLocaleString(), sub: `${summary.totalProjects} coding projects` },
          { label: 'Knowledge Base', value: summary.totalDocuments.toLocaleString(), sub: `${summary.totalMemories} saved memories` },
        ].map((kpi) => (
          <div
            key={kpi.label}
            className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-5"
          >
            <div className="text-xs text-slate-500 dark:text-slate-400">{kpi.label}</div>
            <div className="mt-1 font-display text-2xl font-bold tabular-nums">{kpi.value}</div>
            <div className="mt-1 text-xs text-slate-500 font-mono tabular-nums">{kpi.sub}</div>
          </div>
        ))}
      </div>

      {/* Quota Progress */}
      <div className="grid md:grid-cols-2 gap-5">
        <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-5 space-y-2">
          <div className="flex justify-between text-xs">
            <span className="font-medium">Daily Message Quota</span>
            <span className="font-mono tabular-nums text-slate-500">
              {summary.dailyQuotaUsed} / {summary.dailyQuotaLimit}
            </span>
          </div>
          <div className="h-2 rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden">
            <div className="h-full bg-zinc-900 dark:bg-white rounded-full" style={{ width: `${msgPct}%` }} />
          </div>
        </div>

        <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-5 space-y-2">
          <div className="flex justify-between text-xs">
            <span className="font-medium">Monthly Studio Visual Quota</span>
            <span className="font-mono tabular-nums text-zinc-500">
              {summary.imageQuotaUsed} / {summary.imageQuotaLimit}
            </span>
          </div>
          <div className="h-2 rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden">
            <div className="h-full bg-zinc-600 dark:bg-zinc-400 rounded-full" style={{ width: `${imgPct}%` }} />
          </div>
        </div>
      </div>

      {/* Model Usage & Recent Activity */}
      <div className="grid lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-5">
          <h2 className="font-display text-sm font-semibold mb-4">Model Usage Breakdown</h2>
          {summary.modelBreakdown.length === 0 ? (
            <p className="text-xs text-slate-500 py-4">No model requests recorded yet.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-white/[0.07] text-slate-500">
                    <th className="py-2 text-left font-medium">Model</th>
                    <th className="py-2 text-right font-medium">Requests</th>
                    <th className="py-2 text-right font-medium">Tokens</th>
                    <th className="py-2 text-right font-medium">Avg Latency</th>
                  </tr>
                </thead>
                <tbody>
                  {summary.modelBreakdown.map((row) => (
                    <tr key={row.modelId} className="border-b border-slate-100 dark:border-white/[0.04]">
                      <td className="py-2.5 font-mono">{row.modelId}</td>
                      <td className="py-2.5 text-right font-mono tabular-nums">{row.requests}</td>
                      <td className="py-2.5 text-right font-mono tabular-nums">{row.tokens.toLocaleString()}</td>
                      <td className="py-2.5 text-right font-mono tabular-nums">{row.avgLatencyMs} ms</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="lg:col-span-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-5">
          <h2 className="font-display text-sm font-semibold mb-4">Recent Activity</h2>
          {summary.recentActivity.length === 0 ? (
            <p className="text-xs text-slate-500 py-4">No recent activity logged.</p>
          ) : (
            <div className="space-y-3">
              {summary.recentActivity.map((act) => (
                <div key={act.id} className="flex items-center justify-between text-xs border-b border-slate-100 dark:border-white/[0.04] pb-2">
                  <div>
                    <div className="font-medium capitalize">{act.action.replace(':', ' · ')}</div>
                    <div className="text-slate-500 font-mono text-[11px]">{act.detail}</div>
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono tabular-nums">
                    {new Date(act.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
