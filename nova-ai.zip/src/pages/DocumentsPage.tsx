import React, { useEffect, useRef, useState } from 'react';
import { CheckSquare, FileText, Loader2, Send, Square, Trash2, Upload } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { MarkdownRenderer } from '../components/ui/MarkdownRenderer';
import type { UploadedDocument } from '../types/nova';

export function DocumentsPage() {
  const { notify } = useAuth();
  const [docs, setDocs] = useState<UploadedDocument[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [question, setQuestion] = useState('');
  const [mode, setMode] = useState<'qa' | 'report' | 'compare' | 'spreadsheet'>('qa');
  const [querying, setQuerying] = useState(false);
  const [answer, setAnswer] = useState('');
  const [sources, setSources] = useState<
    Array<{ index: number; filename: string; sectionLabel: string; excerpt: string; score: number }>
  >([]);
  const fileRef = useRef<HTMLInputElement | null>(null);

  const loadDocs = async () => {
    try {
      const res = await apiFetch<{ documents: UploadedDocument[] }>('/api/documents');
      setDocs(res.documents || []);
      if (res.documents?.length > 0 && selectedIds.length === 0) {
        setSelectedIds([res.documents[0].id]);
      }
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to load documents', 'error');
    }
  };

  useEffect(() => {
    void loadDocs();
  }, []);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const res = await apiFetch<{ document: UploadedDocument }>('/api/documents/upload', {
        method: 'POST',
        body: fd,
      });
      setDocs((prev) => [res.document, ...prev]);
      setSelectedIds((prev) => [...prev, res.document.id]);
      notify(`Indexed ${file.name} (${res.document.chunkCount} chunks)`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Upload failed', 'error');
    } finally {
      setUploading(false);
    }
  };

  const handleQuery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedIds.length === 0) {
      notify('Select at least one document first', 'error');
      return;
    }
    setQuerying(true);
    setAnswer('');
    setSources([]);
    try {
      const res = await apiFetch<{
        answer: string;
        sources: Array<{ index: number; filename: string; sectionLabel: string; excerpt: string; score: number }>;
      }>('/api/documents/query', {
        method: 'POST',
        body: JSON.stringify({ fileIds: selectedIds, question, mode }),
      });
      setAnswer(res.answer);
      setSources(res.sources || []);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Analysis failed', 'error');
    } finally {
      setQuerying(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await apiFetch(`/api/documents/${id}`, { method: 'DELETE' });
      setDocs((prev) => prev.filter((d) => d.id !== id));
      setSelectedIds((prev) => prev.filter((x) => x !== id));
      notify('Document removed', 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Delete failed', 'error');
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Document Intelligence & RAG</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Upload PDF, DOCX, XLSX, CSV, TXT, images, or source code for chunked semantic Q&A and reports.
          </p>
        </div>

        <div>
          <input
            ref={fileRef}
            type="file"
            accept=".pdf,.docx,.txt,.md,.csv,.xlsx,.xls,.json,.ts,.tsx,.js,.py,image/*"
            onChange={handleUpload}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-950 text-sm font-medium cursor-pointer"
          >
            {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
            <span>{uploading ? 'Parsing & Indexing...' : 'Upload Document'}</span>
          </button>
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-6">
        {/* Document List */}
        <div className="lg:col-span-5 space-y-3">
          <div className="text-xs font-semibold text-zinc-500 dark:text-zinc-400">
            Indexed Files ({docs.length}) · Select files to query
          </div>
          {docs.length === 0 ? (
            <div className="p-8 rounded-2xl border border-dashed border-zinc-300 dark:border-zinc-700 text-center text-sm text-zinc-500">
              No documents uploaded yet. Upload a PDF, spreadsheet, or note to begin.
            </div>
          ) : (
            docs.map((doc) => {
              const checked = selectedIds.includes(doc.id);
              return (
                <div
                  key={doc.id}
                  onClick={() => toggleSelect(doc.id)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-colors ${
                    checked
                      ? 'bg-zinc-200/70 dark:bg-zinc-800 border-zinc-400 dark:border-zinc-600'
                      : 'bg-white dark:bg-[#141416] border-zinc-200 dark:border-zinc-800'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5 min-w-0">
                      {checked ? (
                        <CheckSquare className="w-4 h-4 text-zinc-900 dark:text-white shrink-0 mt-0.5" />
                      ) : (
                        <Square className="w-4 h-4 text-zinc-400 shrink-0 mt-0.5" />
                      )}
                      <div className="min-w-0">
                        <div className="font-medium text-sm truncate">{doc.filename}</div>
                        <div className="text-[11px] text-slate-500 font-mono tabular-nums mt-0.5">
                          {(doc.sizeBytes / 1024).toFixed(1)} KB · {doc.chunkCount} chunks
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        void handleDelete(doc.id);
                      }}
                      className="p-1 text-slate-400 hover:text-red-400 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  {doc.summary && (
                    <p className="mt-2.5 text-xs text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed">
                      {doc.summary}
                    </p>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* RAG Query Console */}
        <div className="lg:col-span-7 space-y-5">
          <form
            onSubmit={handleQuery}
            className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-5 space-y-4"
          >
            <div className="flex flex-wrap items-center gap-2">
              {(
                [
                  ['qa', 'Ask Questions'],
                  ['report', 'Executive Report'],
                  ['spreadsheet', 'Analyze Spreadsheet'],
                  ['compare', 'Compare Documents'],
                ] as const
              ).map(([m, label]) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMode(m)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer ${
                    mode === m
                      ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-950'
                      : 'bg-zinc-100 dark:bg-[#09090B] text-zinc-600 dark:text-zinc-300'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            <textarea
              rows={3}
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Ask a specific question about the selected documents, request metric extraction, or generate a report..."
              className="w-full p-3 rounded-xl bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-sm focus:outline-none focus:border-zinc-500"
            />

            <div className="flex items-center justify-between">
              <span className="text-xs text-zinc-500">
                {selectedIds.length} document{selectedIds.length === 1 ? '' : 's'} selected
              </span>
              <button
                type="submit"
                disabled={querying || selectedIds.length === 0}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 disabled:opacity-50 text-white dark:text-zinc-950 text-xs font-medium cursor-pointer"
              >
                {querying ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                <span>{querying ? 'Analyzing...' : 'Run Document Analysis'}</span>
              </button>
            </div>
          </form>

          {answer ? (
            <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-6 space-y-5">
              <MarkdownRenderer content={answer} />

              {sources.length > 0 && (
                <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800 space-y-2">
                  <div className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">Retrieved Evidence Excerpts</div>
                  {sources.map((s) => (
                    <div
                      key={s.index}
                      className="p-3 rounded-xl bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/[0.06] text-xs"
                    >
                      <div className="font-medium text-slate-900 dark:text-white">
                        [Source {s.index}] {s.filename} · {s.sectionLabel}
                      </div>
                      <p className="mt-1 text-slate-600 dark:text-slate-400">{s.excerpt}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-10 text-center text-sm text-slate-500">
              <FileText className="w-8 h-8 mx-auto mb-2 opacity-40" />
              Select documents on the left and run a query to inspect grounded answers and section citations.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
