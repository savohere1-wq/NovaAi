import React, { useEffect, useState } from 'react';
import { Download, Edit2, MessageSquare, Search, Trash2 } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import type { ChatMessage, Conversation } from '../types/nova';

interface HistoryPageProps {
  onSelectConversation: (id: string) => void;
  navigate: (path: string) => void;
}

export function HistoryPage({ onSelectConversation, navigate }: HistoryPageProps) {
  const { notify } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [query, setQuery] = useState('');
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameText, setRenameText] = useState('');

  const load = async (q = '') => {
    try {
      const res = await apiFetch<{ conversations: Conversation[] }>(
        q ? `/api/conversations?q=${encodeURIComponent(q)}` : '/api/conversations'
      );
      setConversations(res.conversations || []);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to load history', 'error');
    }
  };

  useEffect(() => {
    void load(query);
  }, [query]);

  const handleRename = async (id: string) => {
    if (!renameText.trim()) return;
    try {
      await apiFetch(`/api/conversations/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ title: renameText.trim() }),
      });
      setConversations((prev) => prev.map((c) => (c.id === id ? { ...c, title: renameText.trim() } : c)));
      setRenamingId(null);
      notify('Conversation renamed', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Rename failed', 'error');
    }
  };

  const handleExport = async (conv: Conversation) => {
    try {
      const res = await apiFetch<{ messages: ChatMessage[] }>(`/api/conversations/${conv.id}/messages`);
      const blob = new Blob([JSON.stringify({ conversation: conv, messages: res.messages }, null, 2)], {
        type: 'application/json',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${conv.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Export failed', 'error');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await apiFetch(`/api/conversations/${id}`, { method: 'DELETE' });
      setConversations((prev) => prev.filter((c) => c.id !== id));
      notify('Conversation deleted', 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Delete failed', 'error');
    }
  };

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Conversation History</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Search, rename, export JSON transcripts, or resume any thread.
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search titles and messages..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-white dark:bg-[#141416] border border-zinc-200 dark:border-zinc-800 text-sm focus:outline-none focus:border-zinc-500"
          />
        </div>
      </div>

      <div className="space-y-2.5">
        {conversations.length === 0 ? (
          <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-10 text-center text-sm text-zinc-500">
            No conversations found.
          </div>
        ) : (
          conversations.map((conv) => (
            <div
              key={conv.id}
              className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416]"
            >
              <div className="min-w-0 flex-1">
                {renamingId === conv.id ? (
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={renameText}
                      onChange={(e) => setRenameText(e.target.value)}
                      className="px-2.5 py-1 rounded-lg bg-zinc-50 dark:bg-[#09090B] border border-zinc-300 dark:border-zinc-700 text-sm"
                    />
                    <button
                      type="button"
                      onClick={() => void handleRename(conv.id)}
                      className="px-2.5 py-1 rounded-lg bg-zinc-900 dark:bg-white text-white dark:text-zinc-950 text-xs font-medium cursor-pointer"
                    >
                      Save
                    </button>
                    <button
                      type="button"
                      onClick={() => setRenamingId(null)}
                      className="px-2.5 py-1 rounded-lg border border-zinc-300 dark:border-zinc-700 text-xs cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      onSelectConversation(conv.id);
                      navigate('/chat');
                    }}
                    className="text-left font-medium text-sm hover:text-zinc-600 dark:hover:text-zinc-300 truncate block w-full cursor-pointer"
                  >
                    {conv.title}
                  </button>
                )}
                <div className="text-xs text-slate-500 font-mono tabular-nums mt-1">
                  {conv.modelId} · {conv.messageCount ?? 0} messages · {new Date(conv.updatedAt).toLocaleString()}
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    onSelectConversation(conv.id);
                    navigate('/chat');
                  }}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-white/10 text-xs hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Open</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setRenamingId(conv.id);
                    setRenameText(conv.title);
                  }}
                  title="Rename"
                  className="p-2 rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => void handleExport(conv)}
                  title="Export JSON"
                  className="p-2 rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => void handleDelete(conv.id)}
                  title="Delete"
                  className="p-2 rounded-lg text-slate-400 hover:text-red-500 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
