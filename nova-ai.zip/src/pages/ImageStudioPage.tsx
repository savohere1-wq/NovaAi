import React, { useEffect, useRef, useState } from 'react';
import { Download, Image as ImageIcon, Loader2, Sparkles, Trash2, Upload, X } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import type { GeneratedImageItem } from '../types/nova';

export function ImageStudioPage() {
  const { notify } = useAuth();
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState('16:9');
  const [quality, setQuality] = useState('hd');
  const [style, setStyle] = useState('Architectural Editorial');
  const [referenceImage, setReferenceImage] = useState<{ base64: string; mimeType: string; name: string } | null>(null);
  const [generating, setGenerating] = useState(false);
  const [images, setImages] = useState<GeneratedImageItem[]>([]);
  const [selected, setSelected] = useState<GeneratedImageItem | null>(null);
  const [activeMode, setActiveMode] = useState('gemini-4-hydrogen-vector-studio');
  const fileRef = useRef<HTMLInputElement | null>(null);

  const loadGallery = async () => {
    try {
      const data = await apiFetch<{ images: GeneratedImageItem[]; activeMode: string }>('/api/images');
      setImages(data.images || []);
      setActiveMode(data.activeMode);
      if (data.images?.[0] && !selected) {
        setSelected(data.images[0]);
      }
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to load gallery', 'error');
    }
  };

  useEffect(() => {
    void loadGallery();
  }, []);

  const handleUploadReference = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      setReferenceImage({ base64, mimeType: file.type, name: file.name });
    };
    reader.readAsDataURL(file);
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    setGenerating(true);
    try {
      const res = await apiFetch<{ image: GeneratedImageItem }>('/api/images/generate', {
        method: 'POST',
        body: JSON.stringify({
          prompt,
          aspectRatio,
          quality,
          style,
          referenceImageBase64: referenceImage?.base64,
          referenceImageMimeType: referenceImage?.mimeType,
        }),
      });
      setImages((prev) => [res.image, ...prev]);
      setSelected(res.image);
      notify('Visual generated and saved to gallery', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Generation failed', 'error');
    } finally {
      setGenerating(false);
    }
  };

  const handleDownload = (item: GeneratedImageItem, format: 'original' | 'png') => {
    if (format === 'original' || item.mimeType !== 'image/svg+xml') {
      const a = document.createElement('a');
      a.href = item.dataUrl;
      a.download = `nova-studio-${item.id.slice(0, 8)}.${item.mimeType === 'image/svg+xml' ? 'svg' : 'png'}`;
      a.click();
      return;
    }

    // Convert SVG to high-res PNG via Canvas
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width || 1200;
      canvas.height = img.height || 900;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      const pngUrl = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = pngUrl;
      a.download = `nova-studio-${item.id.slice(0, 8)}.png`;
      a.click();
    };
    img.src = item.dataUrl;
  };

  const handleDelete = async (id: string) => {
    try {
      await apiFetch(`/api/images/${id}`, { method: 'DELETE' });
      setImages((prev) => prev.filter((i) => i.id !== id));
      if (selected?.id === id) setSelected(null);
      notify('Image deleted', 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Delete failed', 'error');
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Image Generation Studio</h1>
          <p className="text-sm text-zinc-500 dark:text-zinc-400">
            Active Engine: <span className="font-mono text-xs text-zinc-900 dark:text-zinc-200">{activeMode}</span> · Prompt Enhancement · Multi-Aspect Gallery
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-6">
        {/* Controls */}
        <form
          onSubmit={handleGenerate}
          className="lg:col-span-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-5 space-y-4 h-fit"
        >
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
              Visual Prompt
            </label>
            <textarea
              rows={4}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe lighting, geometry, subject, mood, and composition..."
              className="w-full p-3 rounded-xl bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/10 text-sm focus:outline-none focus:border-zinc-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                Aspect Ratio
              </label>
              <select
                value={aspectRatio}
                onChange={(e) => setAspectRatio(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/10 text-xs"
              >
                <option value="1:1">1:1 Square</option>
                <option value="16:9">16:9 Widescreen</option>
                <option value="9:16">9:16 Vertical</option>
                <option value="4:3">4:3 Standard</option>
                <option value="3:4">3:4 Portrait</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                Quality
              </label>
              <select
                value={quality}
                onChange={(e) => setQuality(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/10 text-xs"
              >
                <option value="standard">Standard</option>
                <option value="hd">High Detail</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-300 mb-1.5">
              Aesthetic Style
            </label>
            <select
              value={style}
              onChange={(e) => setStyle(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-xs"
            >
              <option>Architectural Editorial</option>
              <option>Monochrome Obsidian & Silver</option>
              <option>Technical Isometric Vector</option>
              <option>Minimalist Geometric Poster</option>
              <option>Cinematic Industrial Scene</option>
            </select>
          </div>

          <div>
            <input ref={fileRef} type="file" accept="image/*" onChange={handleUploadReference} className="hidden" />
            {referenceImage ? (
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-xs">
                <span className="truncate">{referenceImage.name}</span>
                <button type="button" onClick={() => setReferenceImage(null)} className="text-zinc-400 hover:text-red-400 cursor-pointer">
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="w-full py-2 px-3 rounded-xl border border-dashed border-zinc-300 dark:border-zinc-700 text-xs text-zinc-600 dark:text-zinc-300 hover:border-zinc-500 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Optional Reference Image (Edit / Variation)</span>
              </button>
            )}
          </div>

          <button
            type="submit"
            disabled={generating || !prompt.trim()}
            className="w-full py-2.5 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 disabled:opacity-50 text-white dark:text-zinc-950 text-sm font-medium flex items-center justify-center gap-2 cursor-pointer"
          >
            {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>{generating ? 'Synthesizing Visual...' : 'Generate Visual'}</span>
          </button>
        </form>

        {/* Preview & Gallery */}
        <div className="lg:col-span-8 space-y-6">
          <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-5">
            {selected ? (
              <div className="space-y-4">
                <div className="rounded-xl overflow-hidden bg-[#09090B] border border-zinc-800 flex items-center justify-center max-h-[460px]">
                  <img
                    src={selected.dataUrl}
                    alt={selected.prompt}
                    referrerPolicy="no-referrer"
                    className="max-h-[460px] w-auto object-contain"
                  />
                </div>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium text-slate-900 dark:text-white truncate">{selected.prompt}</div>
                    {selected.enhancedPrompt && (
                      <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2">
                        Enhanced: {selected.enhancedPrompt}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleDownload(selected, 'png')}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-900 dark:bg-white text-white dark:text-zinc-950 text-xs font-medium cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download PNG</span>
                    </button>
                    {selected.mimeType === 'image/svg+xml' && (
                      <button
                        type="button"
                        onClick={() => handleDownload(selected, 'original')}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-700 text-xs font-medium cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>SVG</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-[340px] flex flex-col items-center justify-center text-zinc-400 text-sm">
                <ImageIcon className="w-10 h-10 mb-3 opacity-40" />
                <span>Enter a prompt to generate your first visual in NOVA Studio.</span>
              </div>
            )}
          </div>

          <div>
            <h2 className="font-display text-sm font-semibold mb-3">Personal Gallery ({images.length})</h2>
            {images.length === 0 ? (
              <p className="text-xs text-zinc-500">No generated visuals yet.</p>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {images.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => setSelected(item)}
                    className={`group relative rounded-xl overflow-hidden border cursor-pointer bg-[#09090B] aspect-square ${
                      selected?.id === item.id ? 'border-zinc-900 dark:border-white ring-1 ring-zinc-900 dark:ring-white' : 'border-zinc-200 dark:border-zinc-800'
                    }`}
                  >
                    <img
                      src={item.dataUrl}
                      alt={item.prompt}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        void handleDelete(item.id);
                      }}
                      aria-label="Delete image"
                      className="opacity-0 group-hover:opacity-100 absolute top-2 right-2 p-1.5 rounded-lg bg-black/70 text-white hover:text-red-400 transition-opacity cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
