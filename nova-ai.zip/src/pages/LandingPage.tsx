import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Check, Moon, Sun } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface LandingPageProps {
  navigate: (path: string) => void;
}

export function LandingPage({ navigate }: LandingPageProps) {
  const { user, models, theme, setTheme } = useAuth();

  const primaryCta = () => {
    navigate(user ? '/chat' : '/register');
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-[#09090B] text-slate-900 dark:text-white transition-colors">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="sticky top-0 z-40 border-b border-slate-200/80 dark:border-white/[0.08] bg-white/85 dark:bg-[#09090B]/85 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-8">
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              navigate('/');
            }}
            className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0"
          >
            NOVA AI
          </a>

          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600 dark:text-slate-300">
            <a href="#capabilities" className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0">
              Capabilities
            </a>
            <a href="#models" className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0">
              Models
            </a>
            <a href="#workspace" className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0">
              Workspace
            </a>
            <a href="#pricing" className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0">
              Pricing
            </a>
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={primaryCta}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-950 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>{user ? 'Open Workspace' : 'Get Started'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 pt-16 pb-20 lg:pt-24 lg:pb-28">
        <div className="grid lg:grid-cols-12 gap-12 items-stretch">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35 }}
            className="lg:col-span-6 flex flex-col justify-center"
          >
            <div className="text-xs font-medium tracking-wide text-zinc-900 dark:text-zinc-200 mb-4">
              Multi-Model Intelligence · Live Web Grounding · Private RAG
            </div>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-[3.5rem] font-bold tracking-tight leading-[1.08] text-balance text-slate-900 dark:text-white">
              One unified platform for reasoning, research, code, and visual synthesis.
            </h1>
            <p className="mt-6 text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl">
              NOVA AI brings together streaming multi-provider chat, Google Search-grounded citations, PDF and spreadsheet intelligence, private semantic memory, voice AI, and a sandboxed coding studio.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={primaryCta}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-950 font-medium text-sm transition-colors cursor-pointer whitespace-nowrap"
              >
                <span>{user ? 'Launch NOVA Chat' : 'Create Free Account'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => navigate(user ? '/tools' : '/login')}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl border border-slate-300 dark:border-white/15 hover:bg-slate-100 dark:hover:bg-white/5 text-slate-800 dark:text-slate-200 font-medium text-sm transition-colors cursor-pointer whitespace-nowrap"
              >
                <span>{user ? 'Explore 15 AI Tools' : 'Sign In'}</span>
              </button>
              <button
                type="button"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                aria-label="Toggle dark or light theme"
                className="inline-flex items-center gap-1.5 px-3 py-3 rounded-xl border border-slate-200 dark:border-white/10 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 text-xs font-medium transition-colors cursor-pointer"
              >
                {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                <span>{theme === 'dark' ? 'Light' : 'Dark'}</span>
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4 }}
            className="lg:col-span-6"
          >
            <div className="relative h-full min-h-[320px] rounded-2xl overflow-hidden border border-zinc-200 dark:border-zinc-800 bg-[#141416]">
              <img
                src="/src/assets/images/hero_nova_workspace_1794634324260.jpg"
                alt="Refractive obsidian glass prisms representing NOVA AI unified intelligence"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#09090B]/85 via-[#09090B]/20 to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 text-white">
                <div className="text-xs text-slate-300 font-mono">
                  English · Hindi · Hinglish · Real-time SSE Streaming
                </div>
                <p className="mt-1.5 text-sm sm:text-base font-medium text-white/95 max-w-md">
                  Server-authenticated AI execution with per-user encrypted persistence and zero exposed keys.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Capabilities Asymmetric Bento Grid */}
      <section id="capabilities" className="max-w-7xl mx-auto px-6 py-16 border-t border-slate-200 dark:border-white/[0.07]">
        <div className="max-w-2xl mb-12">
          <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
            01. Built for real production workflows
          </h2>
          <p className="mt-3 text-slate-600 dark:text-slate-400">
            Every workspace module connects directly to server-side models, document parsers, semantic retrieval, and sandboxed previews.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] overflow-hidden grid sm:grid-cols-2 items-stretch">
            <div className="p-7 flex flex-col justify-between">
              <div>
                <div className="text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-2">Multimodal & Web Research</div>
                <h3 className="font-display text-xl font-semibold text-slate-900 dark:text-white">
                  Grounded answers with verifiable citations
                </h3>
                <p className="mt-3 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  Toggle Live Web Research inside any conversation to retrieve current web pages, extract source domains, and separate verified evidence from AI synthesis.
                </p>
              </div>
              <button
                type="button"
                onClick={() => navigate(user ? '/chat' : '/register')}
                className="mt-6 inline-flex items-center gap-1.5 text-sm font-medium text-zinc-900 dark:text-zinc-200 hover:underline cursor-pointer w-fit"
              >
                <span>Open Conversational Engine</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="min-h-[220px] bg-[#0D0D0F]">
              <img
                src="/src/assets/images/showcase_multimodal_vision_1794634324967.jpg"
                alt="Precision optical lens and crystal prism for multimodal vision and research"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-7 flex flex-col justify-between">
            <div>
              <div className="text-xs font-medium text-zinc-900 dark:text-zinc-200 mb-2">Document RAG & Memory</div>
              <h3 className="font-display text-xl font-semibold text-slate-900 dark:text-white">
                PDF, DOCX, XLSX & Private Context
              </h3>
              <p className="mt-3 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                Upload spreadsheets, PDFs, or source files for chunked semantic Q&A, and manage user-scoped long-term memories with full edit and delete control.
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-slate-200 dark:border-white/[0.07] text-xs text-slate-500 dark:text-slate-400">
              Supported formats · PDF · DOCX · XLSX · CSV · Code
            </div>
          </div>
        </div>
      </section>

      {/* Configured Models Section */}
      <section id="models" className="max-w-7xl mx-auto px-6 py-16 border-t border-slate-200 dark:border-white/[0.07]">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
              02. Active server-configured models
            </h2>
            <p className="mt-2 text-slate-600 dark:text-slate-400">
              Only models with verified server credentials appear here and inside the chat selector.
            </p>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {models.length > 0 ? (
            models.map((m) => (
              <div
                key={m.id}
                className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-6"
              >
                <div className="text-xs text-zinc-600 dark:text-zinc-400 font-medium mb-1">
                  {m.providerLabel} · {(m.capabilities.maxContextTokens / 1000).toLocaleString()}k context
                </div>
                <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-white">{m.name}</h3>
                <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">{m.description}</p>
                <div className="mt-4 pt-3 border-t border-slate-200 dark:border-white/[0.06] text-xs text-slate-500 dark:text-slate-400">
                  {[
                    m.capabilities.streaming && 'Streaming',
                    m.capabilities.vision && 'Vision',
                    m.capabilities.webSearch && 'Web Search',
                    m.capabilities.thinking && 'Deep Thinking',
                  ]
                    .filter(Boolean)
                    .join(' · ')}
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-6 text-sm text-slate-600 dark:text-slate-400">
              Configure <code className="font-mono">GEMINI_API_KEY</code> in server environment variables to activate models.
            </div>
          )}
        </div>
      </section>

      {/* Workspace Showcase */}
      <section id="workspace" className="max-w-7xl mx-auto px-6 py-16 border-t border-slate-200 dark:border-white/[0.07]">
        <div className="grid lg:grid-cols-12 gap-10 items-stretch">
          <div className="lg:col-span-5 rounded-2xl overflow-hidden border border-slate-200 dark:border-white/10 min-h-[280px]">
            <img
              src="/src/assets/images/showcase_code_synthesis_1794634324858.jpg"
              alt="Minimalist engineering desk representing NOVA Coding Workspace"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="lg:col-span-7 flex flex-col justify-center">
            <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
              03. Sandboxed Coding Studio & 15 AI Tools
            </h2>
            <p className="mt-4 text-slate-600 dark:text-slate-300 leading-relaxed">
              Write, debug, explain, and refactor code across multi-file projects with isolated browser iframe previewing—never executing untrusted scripts on the server. Pair it with 15 dedicated workflows for writing, math proofs, translation, data analysis, and resume craft.
            </p>
            <div className="mt-6 grid sm:grid-cols-2 gap-4 text-sm">
              <div className="p-4 rounded-xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416]">
                <div className="font-semibold text-slate-900 dark:text-white">Voice AI & Multilingual</div>
                <p className="mt-1 text-slate-600 dark:text-slate-400 text-xs">
                  Speak in English, Hindi, or Hinglish with neural transcription and natural TTS playback.
                </p>
              </div>
              <div className="p-4 rounded-xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416]">
                <div className="font-semibold text-slate-900 dark:text-white">Image & Vector Studio</div>
                <p className="mt-1 text-slate-600 dark:text-slate-400 text-xs">
                  Prompt enhancement, aspect ratio presets, and persistent personal visual gallery.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="max-w-7xl mx-auto px-6 py-16 border-t border-slate-200 dark:border-white/[0.07]">
        <div className="max-w-2xl mb-10">
          <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
            04. Transparent usage tiers
          </h2>
          <p className="mt-2 text-slate-600 dark:text-slate-400">
            Clear daily message quotas, monthly visual allowances, and server-enforced rate limits.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              name: 'Free',
              audience: 'For personal exploration',
              price: '₹0 / mo',
              items: ['50 AI chat turns daily', 'Live Google Search citations', '15 Studio visuals monthly', '10 MB Document RAG & Memory'],
            },
            {
              name: 'Pro',
              audience: 'For builders and researchers',
              price: '₹1,499 / mo',
              items: ['500 AI chat turns daily', 'Priority multi-provider routing', '200 Studio visuals monthly', '25 MB Multi-document RAG'],
              featured: true,
            },
            {
              name: 'Premium',
              audience: 'For scaling teams',
              price: '₹3,999 / mo',
              items: ['5,000 AI chat turns daily', '2,000 Studio visuals monthly', 'All configured flagship models', 'Full admin & usage telemetry'],
            },
          ].map((tier) => (
            <div
              key={tier.name}
              className={`rounded-2xl p-7 border bg-white dark:bg-[#141416] flex flex-col justify-between ${
                tier.featured ? 'border-zinc-900 dark:border-white' : 'border-zinc-200 dark:border-zinc-800'
              }`}
            >
              <div>
                <div className="text-xs text-slate-500 dark:text-slate-400">{tier.audience}</div>
                <div className="mt-1 flex items-baseline justify-between">
                  <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white">{tier.name}</h3>
                  <span className="font-mono text-lg font-semibold tabular-nums text-slate-900 dark:text-white">
                    {tier.price}
                  </span>
                </div>
                <ul className="mt-6 space-y-3 text-sm text-slate-600 dark:text-slate-300">
                  {tier.items.map((item) => (
                    <li key={item} className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-zinc-900 dark:text-zinc-200 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <button
                type="button"
                onClick={primaryCta}
                className={`mt-8 w-full py-2.5 px-4 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
                  tier.featured
                    ? 'bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-950'
                    : 'border border-slate-300 dark:border-white/15 hover:bg-slate-100 dark:hover:bg-white/5 text-slate-900 dark:text-white'
                }`}
              >
                {user ? 'Manage Plan' : 'Start Free'}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Quiet Footer */}
      <footer className="border-t border-slate-200 dark:border-white/[0.07] py-10">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <div>NOVA AI · Unified Multi-Model Intelligence Platform</div>
          <div className="flex items-center gap-6">
            <button type="button" onClick={() => navigate('/login')} className="hover:text-slate-900 dark:hover:text-white cursor-pointer">
              Sign In
            </button>
            <button type="button" onClick={() => navigate('/register')} className="hover:text-slate-900 dark:hover:text-white cursor-pointer">
              Register
            </button>
            <button type="button" onClick={() => navigate('/chat')} className="hover:text-slate-900 dark:hover:text-white cursor-pointer">
              Workspace
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
