import React, { useEffect, useState } from 'react';
import { Brain, Plus, Trash2 } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import type { UserMemory } from '../types/nova';

export function MemoryPage() {
  const { preferences, updatePreferences, notify } = useAuth();
  const [memories, setMemories] = useState<UserMemory[]>([]);
  const [category, setCategory] = useState<UserMemory['category']>('preference');
  const [content, setContent] = useState('');
  const [filterCat, setFilterCat] = useState<string>('all');
  const [adding, setAdding] = useState(false);

  const loadMemories = async () => {
    try {
      const res = await apiFetch<{ memories: UserMemory[] }>('/api/memories');
      setMemories(res.memories || []);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to load memories', 'error');
    }
  };

  useEffect(() => {
    void loadMemories();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;
    setAdding(true);
    try {
      const res = await apiFetch<{ memory: UserMemory }>('/api/memories', {
        method: 'POST',
        body: JSON.stringify({ category, content }),
      });
      setMemories((prev) => [res.memory, ...prev]);
      setContent('');
      notify('Memory saved privately to your account', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to add memory', 'error');
    } finally {
      setAdding(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await apiFetch(`/api/memories/${id}`, { method: 'DELETE' });
      setMemories((prev) => prev.filter((m) => m.id !== id));
      notify('Memory deleted', 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to delete memory', 'error');
    }
  };

  const filtered = filterCat === 'all' ? memories : memories.filter((m) => m.category === filterCat);

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Long-Term AI Memory</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Private, account-isolated context retrieved semantically during conversations.
          </p>
        </div>

        <button
          type="button"
          onClick={() => updatePreferences({ memoryEnabled: !preferences.memoryEnabled })}
          className={`px-4 py-2 rounded-xl text-xs font-medium border transition-colors cursor-pointer ${
            preferences.memoryEnabled
              ? 'bg-zinc-900 dark:bg-white border-zinc-900 dark:border-white text-white dark:text-zinc-950'
              : 'border-zinc-300 dark:border-zinc-700 text-zinc-500'
          }`}
        >
          {preferences.memoryEnabled ? 'Memory Active' : 'Memory Paused'}
        </button>
      </div>

      {/* Add Memory Form */}
      <form
        onSubmit={handleAdd}
        className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-5 space-y-3"
      >
        <div className="grid sm:grid-cols-4 gap-3">
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as UserMemory['category'])}
            className="px-3 py-2.5 rounded-xl bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-xs font-medium"
          >
            <option value="preference">Preference</option>
            <option value="project">Project Context</option>
            <option value="instruction">Persistent Instruction</option>
            <option value="fact">Personal Fact</option>
          </select>
          <input
            type="text"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="e.g., I build full-stack TypeScript apps and prefer concise code examples."
            className="sm:col-span-2 px-3.5 py-2.5 rounded-xl bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-sm focus:outline-none focus:border-zinc-500"
          />
          <button
            type="submit"
            disabled={adding || !content.trim()}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 disabled:opacity-50 text-white dark:text-zinc-950 text-xs font-medium cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Save Memory</span>
          </button>
        </div>
      </form>

      {/* Category Filter */}
      <div className="flex flex-wrap items-center gap-2">
        {['all', 'preference', 'project', 'instruction', 'fact'].map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setFilterCat(c)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize cursor-pointer ${
              filterCat === c
                ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-950'
                : 'bg-zinc-100 dark:bg-[#141416] text-zinc-600 dark:text-zinc-400'
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Memories List */}
      <div className="space-y-2.5">
        {filtered.length === 0 ? (
          <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-10 text-center text-sm text-zinc-500">
            <Brain className="w-8 h-8 mx-auto mb-2 opacity-40" />
            No saved memories in this category yet.
          </div>
        ) : (
          filtered.map((mem) => (
            <div
              key={mem.id}
              className="flex items-start justify-between gap-4 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416]"
            >
              <div>
                <div className="text-[11px] font-medium text-zinc-500 dark:text-zinc-400 capitalize">
                  {mem.category} · {new Date(mem.updatedAt).toLocaleDateString()}
                </div>
                <p className="mt-1 text-sm text-zinc-800 dark:text-zinc-200">{mem.content}</p>
              </div>
              <button
                type="button"
                onClick={() => void handleDelete(mem.id)}
                aria-label="Delete memory"
                className="p-2 rounded-lg text-slate-400 hover:text-red-500 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer shrink-0"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
