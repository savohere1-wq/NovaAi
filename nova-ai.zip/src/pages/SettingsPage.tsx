import React, { useState } from 'react';
import { Loader2, Moon, Sun, Volume2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../lib/api';
import { SUPPORTED_LANGUAGES, VOICE_PERSONAS } from '../lib/languages';
import type { LanguagePreference, ThinkingMode } from '../types/nova';

export function SettingsPage() {
  const { user, preferences, models, theme, setTheme, updatePreferences, refreshAuth, notify } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);
  const [previewingVoice, setPreviewingVoice] = useState(false);

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      await apiFetch('/api/profile', {
        method: 'PATCH',
        body: JSON.stringify({
          name,
          currentPassword: currentPassword || undefined,
          newPassword: newPassword || undefined,
        }),
      });
      await refreshAuth();
      setCurrentPassword('');
      setNewPassword('');
      notify('Profile updated', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Profile update failed', 'error');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleVoicePreview = async () => {
    setPreviewingVoice(true);
    try {
      const res = await apiFetch<{ audioBase64: string; mimeType: string }>('/api/voice/tts', {
        method: 'POST',
        body: JSON.stringify({
          text: `Hello ${user?.name || 'there'}. This is your selected NOVA AI assistant voice.`,
          voiceName: preferences.voiceName,
        }),
      });
      const audio = new Audio(`data:${res.mimeType};base64,${res.audioBase64}`);
      await audio.play();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Voice preview failed', 'error');
    } finally {
      setPreviewingVoice(false);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight">Settings & Preferences</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Customize interface theme, default AI engine, multilingual behavior, voice persona, and security.
        </p>
      </div>

      {/* Appearance & AI Preferences */}
      <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-6 space-y-5">
        <h2 className="font-display text-base font-semibold">AI & Interface Preferences</h2>

        <div className="flex items-center justify-between py-2 border-b border-zinc-100 dark:border-zinc-800">
          <div>
            <div className="text-sm font-medium">Theme</div>
            <div className="text-xs text-zinc-500">Switch between Carbon Black & Grey Dark or Crisp Light mode</div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setTheme('dark')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer ${
                theme === 'dark' ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-950' : 'bg-zinc-100 dark:bg-[#09090B]'
              }`}
            >
              <Moon className="w-3.5 h-3.5" />
              <span>Dark</span>
            </button>
            <button
              type="button"
              onClick={() => setTheme('light')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer ${
                theme === 'light' ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-950' : 'bg-zinc-100 dark:bg-[#09090B]'
              }`}
            >
              <Sun className="w-3.5 h-3.5" />
              <span>Light</span>
            </button>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1.5">Default Chat Model</label>
            <select
              value={preferences.defaultModel}
              onChange={(e) => void updatePreferences({ defaultModel: e.target.value })}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/10 text-sm"
            >
              {models.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} ({m.providerLabel})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1.5">Preferred Language (All Languages)</label>
            <select
              value={preferences.language}
              onChange={(e) => void updatePreferences({ language: e.target.value as LanguagePreference })}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/10 text-sm"
            >
              {SUPPORTED_LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.label} ({l.nativeLabel})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1.5">Default Thinking Depth</label>
            <select
              value={preferences.thinkingMode}
              onChange={(e) => void updatePreferences({ thinkingMode: e.target.value as ThinkingMode })}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/10 text-sm"
            >
              <option value="low">Low (Fast)</option>
              <option value="medium">Medium (Balanced)</option>
              <option value="high">High (Deep Reasoning)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1.5">Voice AI Persona</label>
            <div className="flex gap-2">
              <select
                value={preferences.voiceName}
                onChange={(e) => void updatePreferences({ voiceName: e.target.value })}
                className="flex-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/10 text-sm"
              >
                {VOICE_PERSONAS.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name} — {v.tagline}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={handleVoicePreview}
                disabled={previewingVoice}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-medium cursor-pointer"
              >
                {previewingVoice ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Volume2 className="w-3.5 h-3.5" />}
                <span>Test</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Account & Security */}
      <form
        onSubmit={handleProfileSave}
        className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-6 space-y-4"
      >
        <h2 className="font-display text-base font-semibold">Account & Password</h2>

        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-zinc-500 mb-1.5">Display Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-zinc-500 mb-1.5">Email Address</label>
            <input
              type="email"
              disabled
              value={user?.email || ''}
              className="w-full px-3.5 py-2 rounded-xl bg-zinc-100 dark:bg-[#0E0E11] border border-zinc-200 dark:border-zinc-800 text-sm text-zinc-500"
            />
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4 pt-2">
          <div>
            <label className="block text-xs font-medium text-zinc-500 mb-1.5">Current Password (optional)</label>
            <input
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="Required only to change password"
              className="w-full px-3.5 py-2 rounded-xl bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-zinc-500 mb-1.5">New Password (optional)</label>
            <input
              type="password"
              minLength={8}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Minimum 8 characters"
              className="w-full px-3.5 py-2 rounded-xl bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-sm"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={savingProfile}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-950 text-sm font-medium cursor-pointer"
        >
          {savingProfile && <Loader2 className="w-4 h-4 animate-spin" />}
          <span>Save Account Changes</span>
        </button>
      </form>
    </div>
  );
}
