import React, { useEffect, useState } from 'react';
import { Check, Info } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import type { PlanDefinition } from '../types/nova';

export function SubscriptionPage() {
  const { user, notify } = useAuth();
  const [plans, setPlans] = useState<PlanDefinition[]>([]);
  const [gateways, setGateways] = useState<{ razorpayConfigured: boolean; stripeConfigured: boolean }>({
    razorpayConfigured: false,
    stripeConfigured: false,
  });

  useEffect(() => {
    apiFetch<{ plans: PlanDefinition[]; gateways: { razorpayConfigured: boolean; stripeConfigured: boolean } }>(
      '/api/subscriptions/plans'
    )
      .then((res) => {
        setPlans(res.plans || []);
        setGateways(res.gateways);
      })
      .catch((err) => notify(err instanceof Error ? err.message : 'Failed to load plans', 'error'));
  }, []);

  const handlePlanAction = (plan: PlanDefinition) => {
    if (plan.id === user?.plan) return;
    if (!gateways.razorpayConfigured && !gateways.stripeConfigured) {
      notify(
        'Payment gateway credentials (RAZORPAY_KEY_ID / STRIPE_SECRET_KEY) are not configured on this server. Administrators can assign plans in /admin.',
        'info'
      );
      return;
    }
    notify('Redirecting to verified payment checkout...', 'info');
  };

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight">Subscription & Quotas</h1>
        <p className="text-sm text-zinc-500 dark:text-zinc-400">
          Current Plan: <span className="font-semibold text-zinc-900 dark:text-white uppercase">{user?.plan || 'free'}</span>
        </p>
      </div>

      {!gateways.razorpayConfigured && !gateways.stripeConfigured && (
        <div className="p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-zinc-100 dark:bg-[#141416] text-xs sm:text-sm text-zinc-700 dark:text-zinc-300 flex items-start gap-3">
          <Info className="w-4 h-4 shrink-0 mt-0.5" />
          <div>
            Billing checkout requires server-side payment gateway credentials (<code className="font-mono">RAZORPAY_KEY_ID</code> / <code className="font-mono">RAZORPAY_KEY_SECRET</code> or <code className="font-mono">STRIPE_SECRET_KEY</code>). NOVA AI never simulates fake payments; server-side signature verification is required before tier changes.
          </div>
        </div>
      )}

      <div className="grid md:grid-cols-3 gap-6">
        {plans.map((plan) => {
          const isCurrent = user?.plan === plan.id;
          return (
            <div
              key={plan.id}
              className={`rounded-2xl p-6 border bg-white dark:bg-[#141416] flex flex-col justify-between ${
                isCurrent ? 'border-zinc-900 dark:border-white' : 'border-zinc-200 dark:border-zinc-800'
              }`}
            >
              <div>
                <div className="text-xs text-zinc-500">{plan.tagline}</div>
                <div className="mt-1 flex items-baseline justify-between">
                  <h2 className="font-display text-xl font-bold">{plan.name}</h2>
                  <span className="font-mono font-semibold tabular-nums">
                    ₹{plan.priceMonthlyInr.toLocaleString()} / mo
                  </span>
                </div>

                <div className="mt-4 py-3 border-y border-zinc-100 dark:border-zinc-800 text-xs font-mono tabular-nums space-y-1 text-zinc-600 dark:text-zinc-300">
                  <div>Daily chat turns: {plan.dailyMessageLimit.toLocaleString()}</div>
                  <div>Monthly visuals: {plan.monthlyImageLimit.toLocaleString()}</div>
                  <div>Max document size: {plan.maxDocumentMb} MB</div>
                </div>

                <ul className="mt-4 space-y-2.5 text-sm text-zinc-600 dark:text-zinc-300">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-zinc-900 dark:text-white shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button
                type="button"
                disabled={isCurrent}
                onClick={() => handlePlanAction(plan)}
                className={`mt-6 w-full py-2.5 px-4 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
                  isCurrent
                    ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-500 cursor-default'
                    : 'bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-950'
                }`}
              >
                {isCurrent ? 'Current Plan' : `Upgrade to ${plan.name}`}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
