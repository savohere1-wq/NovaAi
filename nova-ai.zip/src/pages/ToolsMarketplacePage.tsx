import React, { useEffect, useState } from 'react';
import { ArrowRight, Check, Copy, ExternalLink, Loader2, Play } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { MarkdownRenderer } from '../components/ui/MarkdownRenderer';
import type { CitationSource } from '../types/nova';

interface ToolItem {
  id: string;
  name: string;
  category: 'Writing' | 'Engineering' | 'Research & Study' | 'Business & Creative';
  description: string;
  useSearch?: boolean;
  fields: Array<{
    key: string;
    label: string;
    type: 'text' | 'textarea' | 'select';
    placeholder?: string;
    options?: string[];
    required?: boolean;
  }>;
}

interface ToolsMarketplacePageProps {
  onOpenCodeInWorkspace: (code: string, language: string) => void;
  navigate: (path: string) => void;
}

export function ToolsMarketplacePage({ onOpenCodeInWorkspace, navigate }: ToolsMarketplacePageProps) {
  const { notify } = useAuth();
  const [tools, setTools] = useState<ToolItem[]>([]);
  const [category, setCategory] = useState<string>('All');
  const [selectedTool, setSelectedTool] = useState<ToolItem | null>(null);
  const [inputs, setInputs] = useState<Record<string, string>>({});
  const [running, setRunning] = useState(false);
  const [output, setOutput] = useState('');
  const [citations, setCitations] = useState<CitationSource[]>([]);
  const [meta, setMeta] = useState<{ tokensUsed: number; latencyMs: number } | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    apiFetch<{ tools: ToolItem[] }>('/api/tools')
      .then((res) => {
        setTools(res.tools || []);
        if (res.tools?.[0]) {
          selectTool(res.tools[0]);
        }
      })
      .catch((err) => notify(err instanceof Error ? err.message : 'Failed to load tools', 'error'));
  }, []);

  const selectTool = (tool: ToolItem) => {
    setSelectedTool(tool);
    const defaults: Record<string, string> = {};
    for (const f of tool.fields) {
      if (f.type === 'select' && f.options?.[0]) {
        defaults[f.key] = f.options[0];
      } else {
        defaults[f.key] = '';
      }
    }
    setInputs(defaults);
    setOutput('');
    setCitations([]);
    setMeta(null);
  };

  const handleRun = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTool) return;
    setRunning(true);
    setOutput('');
    setCitations([]);
    try {
      const res = await apiFetch<{
        output: string;
        citations: CitationSource[];
        tokensUsed: number;
        latencyMs: number;
      }>(`/api/tools/${selectedTool.id}/run`, {
        method: 'POST',
        body: JSON.stringify({ inputs }),
      });
      setOutput(res.output);
      setCitations(res.citations || []);
      setMeta({ tokensUsed: res.tokensUsed, latencyMs: res.latencyMs });
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Tool execution failed', 'error');
    } finally {
      setRunning(false);
    }
  };

  const categories = ['All', 'Writing', 'Engineering', 'Research & Study', 'Business & Creative'];
  const filteredTools = category === 'All' ? tools : tools.filter((t) => t.category === category);

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">AI Tools Marketplace</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            15 specialized workflows backed by real multi-step AI synthesis and live web grounding.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1 p-1 rounded-xl bg-zinc-100 dark:bg-[#141416] border border-zinc-200 dark:border-zinc-800">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                category === cat
                  ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-950 shadow-xs'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-6">
        {/* Tool Directory */}
        <div className="lg:col-span-4 space-y-2 max-h-[72vh] overflow-y-auto pr-1">
          {filteredTools.map((tool) => {
            const active = selectedTool?.id === tool.id;
            return (
              <button
                key={tool.id}
                type="button"
                onClick={() => selectTool(tool)}
                className={`w-full text-left p-4 rounded-xl border transition-colors cursor-pointer ${
                  active
                    ? 'bg-zinc-200/70 dark:bg-zinc-800 border-zinc-400 dark:border-zinc-600 text-zinc-900 dark:text-white'
                    : 'bg-white dark:bg-[#141416] border-zinc-200 dark:border-zinc-800 hover:border-zinc-400 dark:hover:border-zinc-600'
                }`}
              >
                <div className="text-[11px] font-medium text-zinc-500 dark:text-zinc-400 mb-0.5">
                  {tool.category} {tool.useSearch ? '· Live Web Search' : ''}
                </div>
                <div className="font-display font-semibold text-sm">{tool.name}</div>
                <p className="mt-1 text-xs text-zinc-500 dark:text-zinc-400 line-clamp-2">{tool.description}</p>
              </button>
            );
          })}
        </div>

        {/* Active Tool Runner */}
        <div className="lg:col-span-8 space-y-6">
          {selectedTool && (
            <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#141416] p-6">
              <div className="flex items-start justify-between gap-4 mb-5">
                <div>
                  <div className="text-xs text-zinc-500 dark:text-zinc-400 font-medium">{selectedTool.category}</div>
                  <h2 className="font-display text-xl font-bold mt-0.5">{selectedTool.name}</h2>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">{selectedTool.description}</p>
                </div>
                {selectedTool.id === 'image-prompt' && (
                  <button
                    type="button"
                    onClick={() => navigate('/image-studio')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/15 text-xs font-medium hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer shrink-0"
                  >
                    <span>Open Image Studio</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <form onSubmit={handleRun} className="space-y-4">
                {selectedTool.fields.map((field) => (
                  <div key={field.key}>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                      {field.label}
                    </label>
                    {field.type === 'textarea' ? (
                      <textarea
                        rows={4}
                        required={field.required}
                        value={inputs[field.key] || ''}
                        onChange={(e) => setInputs((prev) => ({ ...prev, [field.key]: e.target.value }))}
                        placeholder={field.placeholder}
                        className="w-full p-3 rounded-xl bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/10 text-sm focus:outline-none focus:border-zinc-500"
                      />
                    ) : field.type === 'select' ? (
                      <select
                        value={inputs[field.key] || ''}
                        onChange={(e) => setInputs((prev) => ({ ...prev, [field.key]: e.target.value }))}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/10 text-sm focus:outline-none focus:border-zinc-500"
                      >
                        {field.options?.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input
                        type="text"
                        required={field.required}
                        value={inputs[field.key] || ''}
                        onChange={(e) => setInputs((prev) => ({ ...prev, [field.key]: e.target.value }))}
                        placeholder={field.placeholder}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-[#09090B] border border-slate-200 dark:border-white/10 text-sm focus:outline-none focus:border-zinc-500"
                      />
                    )}
                  </div>
                ))}

                <button
                  type="submit"
                  disabled={running}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 disabled:opacity-50 text-white dark:text-zinc-950 text-sm font-medium cursor-pointer"
                >
                  {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
                  <span>{running ? 'Running Tool...' : `Run ${selectedTool.name}`}</span>
                </button>
              </form>
            </div>
          )}

          {output && (
            <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#141416] p-6 space-y-4">
              <div className="flex items-center justify-between gap-3">
                <div className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                  Output {meta ? `· ${(meta.latencyMs / 1000).toFixed(2)}s · ${meta.tokensUsed} tokens` : ''}
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    await navigator.clipboard.writeText(output);
                    setCopied(true);
                    setTimeout(() => setCopied(false), 1600);
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/15 text-xs font-medium cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy Output'}</span>
                </button>
              </div>

              <MarkdownRenderer content={output} onOpenInWorkspace={onOpenCodeInWorkspace} />

              {citations.length > 0 && (
                <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800">
                  <div className="text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-2">Verified Citations</div>
                  <div className="grid sm:grid-cols-2 gap-2">
                    {citations.map((c, i) => (
                      <a
                        key={i}
                        href={c.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-50 dark:bg-[#09090B] border border-zinc-200 dark:border-zinc-800 text-xs hover:border-zinc-400"
                      >
                        <div className="min-w-0">
                          <div className="font-medium truncate">{c.title}</div>
                          <div className="text-[11px] text-slate-500 truncate">{c.domain}</div>
                        </div>
                        <ExternalLink className="w-3.5 h-3.5 shrink-0 text-slate-400" />
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
