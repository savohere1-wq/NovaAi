import React from 'react';
import { LiveVoiceCall } from '../components/voice/LiveVoiceCall';

export function VoiceCallPage() {
  return (
    <div className="h-full w-full">
      <LiveVoiceCall embedded />
    </div>
  );
}
