export type ThemeMode = 'dark' | 'light';
export type UserRole = 'user' | 'admin';
export type PlanTier = 'free' | 'pro' | 'premium';
export type LanguagePreference = string;
export type ThinkingMode = 'low' | 'medium' | 'high';

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  plan: PlanTier;
  avatarUrl?: string | null;
  createdAt: string;
}

export interface UserPreferences {
  theme: ThemeMode;
  defaultModel: string;
  language: LanguagePreference;
  memoryEnabled: boolean;
  thinkingMode: ThinkingMode;
  voiceName: string;
}

export interface ModelCapabilities {
  streaming: boolean;
  vision: boolean;
  webSearch: boolean;
  thinking: boolean;
  maxContextTokens: number;
}

export interface AIModelInfo {
  id: string;
  name: string;
  provider: 'gemini' | 'openai' | 'anthropic' | 'openrouter';
  providerLabel: string;
  description: string;
  available: boolean;
  badge?: string;
  capabilities: ModelCapabilities;
  minPlan: PlanTier;
}

export interface CitationSource {
  title: string;
  url: string;
  domain: string;
  snippet?: string;
}

export interface AttachmentPayload {
  id?: string;
  name: string;
  mimeType: string;
  size: number;
  base64?: string;
  extractedText?: string;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  modelId?: string | null;
  provider?: string | null;
  citations?: CitationSource[];
  attachments?: AttachmentPayload[];
  tokensUsed?: number;
  latencyMs?: number;
  feedback?: 'up' | 'down' | null;
  createdAt: string;
}

export interface Conversation {
  id: string;
  userId: string;
  title: string;
  modelId: string;
  language: LanguagePreference;
  researchMode: boolean;
  createdAt: string;
  updatedAt: string;
  messageCount?: number;
}

export interface UploadedDocument {
  id: string;
  userId: string;
  filename: string;
  mimeType: string;
  sizeBytes: number;
  summary?: string | null;
  chunkCount: number;
  createdAt: string;
}

export interface GeneratedImageItem {
  id: string;
  userId: string;
  prompt: string;
  enhancedPrompt?: string | null;
  provider: string;
  aspectRatio: string;
  quality: string;
  mimeType: string;
  dataUrl: string;
  createdAt: string;
}

export interface UserMemory {
  id: string;
  userId: string;
  category: 'preference' | 'project' | 'fact' | 'instruction';
  content: string;
  relevanceScore?: number;
  createdAt: string;
  updatedAt: string;
}

export interface CodingFile {
  path: string;
  language: string;
  content: string;
}

export interface CodingProject {
  id: string;
  userId: string;
  name: string;
  description: string;
  files: CodingFile[];
  createdAt: string;
  updatedAt: string;
}

export interface UsageSummary {
  totalConversations: number;
  totalMessages: number;
  totalTokens: number;
  avgLatencyMs: number;
  totalImages: number;
  totalDocuments: number;
  totalProjects: number;
  totalMemories: number;
  dailyQuotaUsed: number;
  dailyQuotaLimit: number;
  imageQuotaUsed: number;
  imageQuotaLimit: number;
  modelBreakdown: Array<{ modelId: string; requests: number; tokens: number; avgLatencyMs: number }>;
  recentActivity: Array<{ id: string; action: string; detail: string; createdAt: string }>;
}

export interface ProviderStatus {
  id: string;
  name: string;
  configured: boolean;
  envVar: string;
  models: string[];
  notes: string;
}

export interface PlanDefinition {
  id: PlanTier;
  name: string;
  tagline: string;
  priceMonthlyInr: number;
  priceMonthlyUsd: number;
  dailyMessageLimit: number;
  monthlyImageLimit: number;
  maxDocumentMb: number;
  modelsAllowed: string[];
  features: string[];
}
