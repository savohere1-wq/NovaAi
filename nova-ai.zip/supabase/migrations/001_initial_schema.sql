-- NOVA AI PostgreSQL + pgvector Production Migration for Supabase
-- Run inside Supabase SQL Editor or via psql when deploying with managed PostgreSQL.

create extension if not exists "uuid-ossp";
create extension if not exists vector;

-- 1. Profiles (linked to auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  name text not null,
  role text not null default 'user' check (role in ('user', 'admin')),
  plan text not null default 'free' check (plan in ('free', 'pro', 'premium')),
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 2. User Preferences
create table if not exists public.user_preferences (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  theme text not null default 'dark' check (theme in ('dark', 'light')),
  default_model text not null default 'gemini-4-hydrogen',
  language text not null default 'en' check (language in ('en', 'hi', 'hinglish')),
  memory_enabled boolean not null default true,
  thinking_mode text not null default 'medium' check (thinking_mode in ('low', 'medium', 'high')),
  voice_name text not null default 'Kore',
  updated_at timestamptz not null default now()
);

-- 3. Conversations
create table if not exists public.conversations (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null default 'New Conversation',
  model_id text not null default 'gemini-4-hydrogen',
  language text not null default 'en',
  research_mode boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_conversations_user_updated on public.conversations(user_id, updated_at desc);

-- 4. Messages
create table if not exists public.messages (
  id uuid primary key default uuid_generate_v4(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null check (role in ('user', 'assistant', 'system')),
  content text not null,
  model_id text,
  provider text,
  citations jsonb not null default '[]'::jsonb,
  attachments jsonb not null default '[]'::jsonb,
  tokens_used integer not null default 0,
  latency_ms integer not null default 0,
  feedback text check (feedback in ('up', 'down')),
  created_at timestamptz not null default now()
);
create index if not exists idx_messages_conversation_created on public.messages(conversation_id, created_at asc);

-- 5. Uploaded Files & Document Chunks (pgvector)
create table if not exists public.uploaded_files (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  filename text not null,
  mime_type text not null,
  size_bytes integer not null,
  extracted_text text not null,
  summary text,
  created_at timestamptz not null default now()
);

create table if not exists public.document_chunks (
  id uuid primary key default uuid_generate_v4(),
  file_id uuid not null references public.uploaded_files(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  chunk_index integer not null,
  section_label text,
  content text not null,
  embedding vector(768),
  created_at timestamptz not null default now()
);
create index if not exists idx_document_chunks_file on public.document_chunks(file_id);

-- 6. Generated Images
create table if not exists public.generated_images (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  prompt text not null,
  enhanced_prompt text,
  provider text not null,
  aspect_ratio text not null default '1:1',
  quality text not null default 'standard',
  mime_type text not null default 'image/png',
  storage_url text not null,
  created_at timestamptz not null default now()
);
create index if not exists idx_generated_images_user on public.generated_images(user_id, created_at desc);

-- 7. User Long-Term Memories (pgvector)
create table if not exists public.user_memories (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  category text not null check (category in ('preference', 'project', 'fact', 'instruction')),
  content text not null,
  embedding vector(768),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_user_memories_user on public.user_memories(user_id, updated_at desc);

-- 8. AI Usage Telemetry
create table if not exists public.ai_usage (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  model_id text not null,
  provider text not null,
  endpoint text not null,
  tokens_used integer not null default 0,
  latency_ms integer not null default 0,
  status text not null default 'ok',
  created_at timestamptz not null default now()
);
create index if not exists idx_ai_usage_user_created on public.ai_usage(user_id, created_at desc);

-- 9. User Feedback & Error Logs & Provider Settings
create table if not exists public.user_feedback (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  message_id uuid not null references public.messages(id) on delete cascade,
  rating text not null check (rating in ('up', 'down')),
  comment text,
  created_at timestamptz not null default now()
);

create table if not exists public.ai_provider_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

-- Row Level Security (Strict Owner Isolation)
alter table public.profiles enable row level security;
alter table public.user_preferences enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.uploaded_files enable row level security;
alter table public.document_chunks enable row level security;
alter table public.generated_images enable row level security;
alter table public.user_memories enable row level security;
alter table public.ai_usage enable row level security;
alter table public.user_feedback enable row level security;

create policy "Owner select profiles" on public.profiles for select using (auth.uid() = id);
create policy "Owner update profiles" on public.profiles for update using (auth.uid() = id);
create policy "Owner all prefs" on public.user_preferences for all using (auth.uid() = user_id);
create policy "Owner all conversations" on public.conversations for all using (auth.uid() = user_id);
create policy "Owner all messages" on public.messages for all using (auth.uid() = user_id);
create policy "Owner all files" on public.uploaded_files for all using (auth.uid() = user_id);
create policy "Owner all chunks" on public.document_chunks for all using (auth.uid() = user_id);
create policy "Owner all images" on public.generated_images for all using (auth.uid() = user_id);
create policy "Owner all memories" on public.user_memories for all using (auth.uid() = user_id);
create policy "Owner select usage" on public.ai_usage for select using (auth.uid() = user_id);
create policy "Owner all feedback" on public.user_feedback for all using (auth.uid() = user_id);
